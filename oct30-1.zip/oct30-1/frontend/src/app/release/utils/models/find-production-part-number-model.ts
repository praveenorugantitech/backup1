export class FindProductionPartNumberModel {
    part_number1 : string = "";
    part_number2 :string = "";
    part_number3 :string= "";
    WERS_notice : string = "";
    catch_word:string="";
    software_part_number1:string="";
    software_part_number2:string="";
    software_part_number3:string="";
    calibration_number:string="";
    main_strategy: string="";
    chip_id:string="";

}