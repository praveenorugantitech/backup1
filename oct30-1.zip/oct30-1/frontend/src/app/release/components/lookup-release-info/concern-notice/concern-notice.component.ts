import { Component, OnDestroy, OnInit } from "@angular/core";

import { HttpErrorResponse } from "@angular/common/http";
import { ErrorResponse } from "../../../utils/models/error-response.model";
import { ReleaseUtils } from "../../../utils/ReleaseUtils";
import { FindFirmWare } from "../../../utils/models/concern-notice.model";
import { Router } from "@angular/router";
import { ReleaseService } from "../../../utils/services/release.service";
import { Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";
import { exportToExcelPostModel } from "../../../utils/models/export-excel.model";

@Component({
  selector: "app-concern-notice",
  templateUrl: "./concern-notice.component.html",
  styleUrls: ["./concern-notice.component.scss"], // Corrected to plural
})
export class ConcernNoticeComponent implements OnInit, OnDestroy {
  selectAllChecked: boolean = false;
  findFrimWare: FindFirmWare = {};
  tempShowTable: boolean = false;
  firmwareRecords: any[] = [];
  selectedRecords: Set<string> = new Set();
  private unsubscribe$ = new Subject<void>();

  constructor(private router: Router, private releaseService: ReleaseService) {}

  ngOnInit() {
    // Reset state on component initialization
    this.resetState();
  }

  private resetState() {
    this.findFrimWare = new FindFirmWare();
    this.firmwareRecords = [];
    this.tempShowTable = false;
    this.selectAllChecked = false;
    this.selectedRecords.clear();
  }

  searchWersConcern() {
    this.findFrimWare.wersNotice = "";
    this.firmwareRecords = [];
    this.tempShowTable = false;

    if (!this.findFrimWare?.wersConcern) {
      return; // Early exit if input is empty or undefined
    }

    this.releaseService
      .getFirmwareDetailsByWersConcern(this.findFrimWare.wersConcern)
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe({
        next: (response: any) => {
          this.firmwareRecords = Array.isArray(response) ? response : [];
          this.tempShowTable = true;
        },
        error: (error: HttpErrorResponse) => this.handleError(error),
      });
  }

  searchWersNotice() {
    this.findFrimWare.wersConcern = "";
    this.firmwareRecords = [];
    this.tempShowTable = false;

    if (!this.findFrimWare?.wersNotice) {
      return; // Early exit if input is empty or undefined
    }

    const trimmedNotice = this.findFrimWare.wersNotice.trim();
    if (!this.testNoticeNumber(trimmedNotice)) {
      const modifiedNotice = trimmedNotice.replace(/-/g, " ");
      if (!this.testNoticeNumber(modifiedNotice)) {
        ReleaseUtils.showErrorSweetAlert(
          "Error",
          "WERS Notice has the incorrect format. The format must be 'APED E 12345678 000'.\n4 characters, space, e or i, space, 8 digits, space, 3 digits"
        );
        return;
      }

      this.callFirmwareService(modifiedNotice);
    } else {
      this.callFirmwareService(trimmedNotice);
    }
  }

  private callFirmwareService(notice: string) {
    this.releaseService
      .getFirmwareDetailsByWersNotice(notice)
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe({
        next: (response: any) => {
          this.firmwareRecords = Array.isArray(response) ? response : [];
          this.tempShowTable = true;
        },
        error: (error: HttpErrorResponse) => this.handleError(error),
      });
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage = "An unexpected error occurred.";

    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message; // Client-side error
    } else if (typeof error.error === "string") {
      try {
        const errorResponse: ErrorResponse = JSON.parse(error.error);
        errorMessage = errorResponse.message || errorMessage;
      } catch {
        console.error("Error parsing response");
      }
    } else if (error.error?.message) {
      errorMessage = error.error.message; // Server-side error
    }

    ReleaseUtils.showErrorSweetAlert("Error", errorMessage);
  }

  cancelSubmit() {
    this.resetState();
    window.scrollTo({ top: 0, behavior: "smooth" });
    this.router.navigate(["/"]);
  }

  toggleSelectAll(event: Event) {
    const isChecked = (event.target as HTMLInputElement).checked;
    this.selectAllChecked = isChecked;

    if (isChecked) {
      this.firmwareRecords.forEach((record) => {
        this.selectedRecords.add(record.assemblyPN);
      });
    } else {
      this.selectedRecords.clear();
    }
  }

  isRecordSelected(assemblyPN: string): boolean {
    return this.selectedRecords.has(assemblyPN);
  }

  toggleRecordSelection(assemblyPN: string) {
    if (this.selectedRecords.has(assemblyPN)) {
      this.selectedRecords.delete(assemblyPN);
    } else {
      this.selectedRecords.add(assemblyPN);
    }
  }

  exportToXML() {
    const partNumbers = Array.from(this.selectedRecords);
    const dataToSend: exportToExcelPostModel = new exportToExcelPostModel();
    dataToSend.partNumbers = partNumbers;
    dataToSend.fileName = "FirmwareExport.xml";

    this.releaseService.exportPartsToXML(dataToSend).subscribe(
      (response) => {
        const blob = new Blob([response], {
          type: "text/xml",
        });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "FirmwareExport.xml";
        a.click();
        window.URL.revokeObjectURL(url);
      },
      (error) => {
        console.error("Error exporting parts to xml:", error);
      }
    );
  }

  exportToExcel() {
    const partNumbers = Array.from(this.selectedRecords);
    this.releaseService.exportPartsToExcel(partNumbers).subscribe(
      (response) => {
        const blob = new Blob([response], {
          type: "application/vnd.openxmlformats",
        });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "FirmwareExport.xlsx";
        a.click();
        window.URL.revokeObjectURL(url);
      },
      (error) => {
        console.error("Error exporting parts to excel:", error);
      }
    );
  }

  testNoticeNumber(notice: string): boolean {
    const regex =
      /^[a-z0-9]{4}\s[iesnx]\s\d{8}\s\d{3}$|^[a-z0-9]{4}[iesnx]\d{8}\d{3}$|^[a-z0-9]{4}-[iesnx]-\d{8}-\d{3}$/i;
    return regex.test(notice);
  }

  ngOnDestroy() {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }
}
