import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CdsRoutingModule } from './cds-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CdsRoutingModule
  ]
})
export class CdsModule { }
