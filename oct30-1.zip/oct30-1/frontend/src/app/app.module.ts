import { NgModule } from "@angular/core";
import { provideHttpClient } from "@angular/common/http";
import { ToastrModule } from "ngx-toastr";
import { FileDownloadComponent } from "./utils/file-download/file-download.component";

@NgModule({
  declarations: [FileDownloadComponent],
  imports: [
    ToastrModule.forRoot({
      timeOut: 3000,
      positionClass: "toast-top-right",
      preventDuplicates: true,
      progressBar: true,
    }),
  ],
  providers: [provideHttpClient()],
  bootstrap: [],
  exports: [FileDownloadComponent],
})
export class AppModule {}
