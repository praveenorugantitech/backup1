package com.ford.gpcse;

import io.swagger.v3.oas.models.OpenAPI;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.test.context.TestPropertySource;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
@TestPropertySource(properties = {
        "app.openApiTitle=Ford GPSCE Services",
        "app.openApiDescription=Ford Global Powertrain Control Systems Engineering Services includes Module Release, Lookup Release Info, Output Release Info, Procedures, Help, Supplier Request, Adminstrative Operations."
})
class GpcseApplicationTests {

    @Autowired
    private Environment env;

    @Autowired
    private OpenAPI openAPI;

    @Autowired
    private RestTemplate restTemplate;

    @Test
    void contextLoads() {

    }

    @Test
    void main() {
        // This will invoke the main method and check for exceptions
        GpcseApplication.main(new String[]{});
    }

    @Test
    void testCustomOpenAPI() {
        assertNotNull(openAPI);
        assertEquals("Ford GPSCE Services", openAPI.getInfo().getTitle());
        assertEquals("Ford Global Powertrain Control Systems Engineering Services includes Module Release, Lookup Release Info, Output Release Info, Procedures, Help, Supplier Request, Adminstrative Operations.", openAPI.getInfo().getDescription());
    }

    @Test
    void testRestTemplate() {
        assertNotNull(restTemplate);
    }
}
