package com.ford.gpcse.service.impl;

import com.ford.gpcse.service.ReleaseRequestService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ReleaseRequestServiceImpl implements ReleaseRequestService {
}
