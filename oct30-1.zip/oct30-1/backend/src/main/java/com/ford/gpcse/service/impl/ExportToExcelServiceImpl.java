package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.ReleaseRequestSearchInput;
import com.ford.gpcse.service.ExportToExcelService;
import com.ford.gpcse.service.PartNumberSearchExcelService;
import com.ford.gpcse.service.ReleaseRequestSearchExcelService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ExportToExcelServiceImpl implements ExportToExcelService {

    private final PartNumberSearchExcelService partNumberSearchExcelService;
    private final ReleaseRequestSearchExcelService releaseRequestSearchExcelService;


    @Override
    public ByteArrayInputStream exportPartsBasedOnPartNumbers(List<String> partNumbers) throws IOException {
        return partNumberSearchExcelService.exportPartsBasedOnPartNumbers(partNumbers);
    }

    @Override
    public ByteArrayInputStream exportReleaseRequestDetails(ReleaseRequestSearchInput releaseRequestSearchInput) throws IOException {
        return releaseRequestSearchExcelService.exportReleaseRequestDetails(releaseRequestSearchInput);
    }

}
