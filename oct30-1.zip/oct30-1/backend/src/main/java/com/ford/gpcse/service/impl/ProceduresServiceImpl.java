package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.EditPartRequest;
import com.ford.gpcse.common.Constants;
import com.ford.gpcse.entity.Part;
import com.ford.gpcse.exception.UnableToUpdateException;
import com.ford.gpcse.external.email.service.EmailService;
import com.ford.gpcse.model.Email;
import com.ford.gpcse.repository.PartRepository;
import com.ford.gpcse.service.ProceduresService;
import jakarta.persistence.criteria.Predicate;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProceduresServiceImpl implements ProceduresService {

    private final PartRepository partRepository;
    private final EmailService emailService;

    @Override
    @Transactional
    public void editPart(EditPartRequest editPartRequest) {
        Specification<Part> spec = withEditPartCriteria(editPartRequest);

        List<Part> partsToUpdate = partRepository.findAll(spec);

        for (Part part : partsToUpdate) {
            if (editPartRequest.getSoftwarePN() != null) {
                part.setStratCalibPartR(editPartRequest.getSoftwarePN());
            }
            if (editPartRequest.getCatchWord() != null) {
                part.getCatchword().setCatchwordC(editPartRequest.getCatchWord());
            }
            if (editPartRequest.getConcernNumber() != null) {
                part.setConcernC(editPartRequest.getConcernNumber());
            }
            if (editPartRequest.getCalibrationNum() != null) {
                part.setCalibR(editPartRequest.getCalibrationNum());
            }
            if (editPartRequest.getWersConcernDescription() != null) {
                part.setCmtX(editPartRequest.getWersConcernDescription());
            }
            if (editPartRequest.getAppEng() != null) {
                part.setEngineerCdsidC(editPartRequest.getAppEng());
            }
            if (editPartRequest.getComments() != null) {
                part.setProcCmtX(editPartRequest.getComments());
            }
            if (editPartRequest.getBuildLevel() != null) {
                part.setBldLvlC(editPartRequest.getBuildLevel());
            }
            if (editPartRequest.getReleasePriority() != null) {
                part.setPrtyC(editPartRequest.getReleasePriority());
            }
            if (editPartRequest.getReleasePriorityDetail() != null) {
                part.setPrtyDtlX(editPartRequest.getReleasePriorityDetail());
            }
        }

        try {
            List<Part> parts = partRepository.saveAll(partsToUpdate);
            if (parts.isEmpty()) {
                throw new UnableToUpdateException("Unable to update Part Number " + editPartRequest.getPartNumbers().get(0) + ".  Internal Error 1298.");
            }
            // Send Email
            sendEmailReminderToDr(editPartRequest.getPartNumbers(), editPartRequest.getAppEng());

        } catch (DataAccessException e) {
            throw new UnableToUpdateException("Unable to update Part Number " + editPartRequest.getPartNumbers().get(0) + ".  Internal Error 1298.");
        }

    }

    private Specification<Part> withEditPartCriteria(EditPartRequest request) {
        return (root, query, criteriaBuilder) -> {
            assert query != null;
            query.distinct(true);
            Predicate predicate = criteriaBuilder.conjunction();

            // Add predicates based on non-null values
            if (request.getPartNumbers() != null && !request.getPartNumbers().isEmpty()) {
                predicate = criteriaBuilder.and(predicate, root.get(Constants.PART_R).in(request.getPartNumbers()));
            }
            if (request.getSoftwarePN() != null) {
                predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("stratCalibPartR"), request.getSoftwarePN()));
            }
            if (request.getCatchWord() != null) {
                predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("catchword").get("catchwordC"), request.getCatchWord()));
            }
            if (request.getConcernNumber() != null) {
                predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("concernC"), request.getConcernNumber()));
            }
            if (request.getCalibrationNum() != null) {
                predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("calibR"), request.getCalibrationNum()));
            }
            if (request.getWersConcernDescription() != null) {
                predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("cmtX"), request.getWersConcernDescription()));
            }
            if (request.getAppEng() != null) {
                predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("engineerCdsidC"), request.getAppEng()));
            }
            if (request.getComments() != null) {
                predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("procCmtX"), request.getComments()));
            }
            if (request.getBuildLevel() != null) {
                predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("bldLvlC"), request.getBuildLevel()));
            }
            if (request.getReleasePriority() != null) {
                predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("prtyC"), request.getReleasePriority()));
            }
            if (request.getReleasePriorityDetail() != null) {
                predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("prtyDtlX"), request.getReleasePriorityDetail()));
            }

            return predicate;
        };
    }

    public void sendEmailReminderToDr(List<String> partNumbers, String appEngineer) {
        try {
            // Combine specifications
            Specification<Part> spec = engineerNotEqual(appEngineer)
                    .and(partNumberIn(partNumbers));

            // Execute the query
            List<Part> parts = partRepository.findAll(spec);

            // Create and send emails
            for (Part part : parts) {
                String partNumber = part.getPartR();
                String concern = part.getConcernC();

                // Build and send email
                String emailBody = "<html><body><p>" + appEngineer + " has requested parts for " + concern + ".</p>" +
                        "<pre>" + partNumber + "</pre></body></html>";

                Email email = Email.builder()
                        .from("")// pcserel@ford.com
                        .to(List.of(appEngineer))
                        .subject(appEngineer + " has requested parts for " + concern + ".")
                        .body(emailBody)
                        .build();

                emailService.sendMail(email);
            }
        } catch (Exception e) {
            log.error("Error occurred while sending email reminders: {}", e.getMessage(), e);
        }
    }

    private Specification<Part> engineerNotEqual(String appEngineer) {
        return (root, query, criteriaBuilder) ->
                criteriaBuilder.notEqual(root.get("engineerCdsidC"), appEngineer);
    }

    private Specification<Part> partNumberIn(List<String> partNumbers) {
        return (root, query, criteriaBuilder) ->
                root.get(Constants.PART_R).in(partNumbers);
    }
}
