package com.ford.gpcse.repository;

import com.ford.gpcse.entity.RelUsg;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository interface for accessing RelUsg entities.
 * Extends JpaRepository to provide standard CRUD operations.
 */
@Repository
public interface RelUsgRepository extends JpaRepository<RelUsg, String> {

    /**
     * Finds a RelUsg entity by its release usage code.
     *
     * @param releaseUsageCode the code of the release usage to search for
     * @return the matching RelUsg entity, or null if not found
     */
    RelUsg findByRelUsgC(String releaseUsageCode);

    /**
     * Fetches a list of active RelUsg entities that are not archived.
     * The results are ordered by the sort order field.
     *
     * @return a list of active RelUsg entities
     */
    @Query("SELECT ru FROM RelUsg ru WHERE ru.archF = 'N' ORDER BY ru.sortOrdR")
    List<RelUsg> fetchActiveReleaseUsages();
}
