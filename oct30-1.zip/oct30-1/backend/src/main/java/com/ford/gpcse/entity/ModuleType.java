package com.ford.gpcse.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCMR14_MODULE_TYP")
public class ModuleType {

    @Id
    @Column(name = "PCMR14_MODULE_TYP_C")
    private String moduleTypC;

    @Column(name = "PCMR14_MODULE_TYP_X")
    private String moduleTypX;

    @Column(name = "PCMR14_ARCH_F")
    private String archF;

    @Column(name = "PCMR14_SORT_ORD_R", precision = 4, scale = 0)
    private BigDecimal sortOrdR;

    @Column(name = "PCMR14_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR14_CREATE_S", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR14_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR14_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;

    @Column(name = "PCMR14_VADR_MODULE_TYP_C")
    private String vadrModuleTypC;

    @Column(name = "PCMR14_CAN_NODE_D")
    private String canNodeD;

    @Column(name = "PCMR14_CAN_EXPLCT_GTWY_C")
    private String canExplctGtwyC;

    @Column(name = "PCMR14_CAN_SUB_NETWRK_ADDR_X")
    private String canSubNetwrkAddrX;

    @Column(name = "PCMR14_CAN_SUB_NODE_ADDR_X")
    private String canSubNodeAddrX;
}
