package com.ford.gpcse.service;

import com.ford.gpcse.bo.ReleaseRequestSearchInput;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

public interface ExportToExcelService {
    ByteArrayInputStream exportPartsBasedOnPartNumbers(List<String> partNumbers) throws IOException;

    ByteArrayInputStream exportReleaseRequestDetails(ReleaseRequestSearchInput releaseRequestSearchInput) throws IOException;


}
