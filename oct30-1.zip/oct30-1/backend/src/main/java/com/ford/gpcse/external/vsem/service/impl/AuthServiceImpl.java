package com.ford.gpcse.external.vsem.service.impl;

import com.ford.gpcse.config.AppConfig;
import com.ford.gpcse.external.vsem.service.AuthService;
import com.ford.gpcse.model.TokenResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

/**
 * Implementation of the AuthService interface for fetching authentication tokens.
 * This service communicates with an OAuth2 provider to obtain a token using client credentials.
 */
@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final AppConfig appConfig; // Configuration properties for OAuth2
    private final RestTemplate restTemplateWithProxy; // RestTemplate configured with a proxy if necessary

    /**
     * Fetches an OAuth2 token using client credentials.
     *
     * @return TokenResponse containing the access token and other details
     * @throws RuntimeException if there is an error during the token fetching process
     */
    @Override
    public TokenResponse fetchToken() {
        // Prepare request body as MultiValueMap for www-form-urlencoded
        MultiValueMap<String, String> requestBody = new LinkedMultiValueMap<>();
        requestBody.add("grant_type", "client_credentials"); // Grant type for client credentials
        requestBody.add("client_id", appConfig.getClientid()); // Client ID from configuration
        requestBody.add("client_secret", appConfig.getClientsecret()); // Client secret from configuration
        requestBody.add("scope", appConfig.getResource()); // Resource scope

        // Set headers for the request
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED); // Content type for form data

        // Create the HttpEntity with body and headers
        HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<>(requestBody, headers);

        try {
            // Send POST request using RestTemplate and return the response
            ResponseEntity<TokenResponse> response = restTemplateWithProxy.exchange(
                    appConfig.getOauthurl(), // OAuth URL from configuration
                    HttpMethod.POST, // HTTP method
                    requestEntity, // Request entity containing body and headers
                    TokenResponse.class // Response type
            );

            // Return the body of the response
            return response.getBody();
        } catch (RestClientException e) {
            // Handle exceptions related to the REST client and throw a runtime exception
            throw new RuntimeException("Error fetching token", e);
        }
    }
}
