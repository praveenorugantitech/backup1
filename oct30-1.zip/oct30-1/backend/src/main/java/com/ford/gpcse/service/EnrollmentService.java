package com.ford.gpcse.service;

import com.ford.gpcse.bo.SupplierEnrollmentRequest;

public interface EnrollmentService {

    String supplierEnrollment(SupplierEnrollmentRequest supplierEnrollmentRequest);

}
