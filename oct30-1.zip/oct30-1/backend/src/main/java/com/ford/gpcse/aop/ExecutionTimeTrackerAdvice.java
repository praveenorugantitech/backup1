package com.ford.gpcse.aop;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

/**
 * Aspect that tracks the execution time of methods annotated with
 *
 * @TrackExecutionTime. It uses Spring AOP to intercept method calls
 * and measure their execution duration.
 */
@Aspect
@Component
@Slf4j
public class ExecutionTimeTrackerAdvice {

    /**
     * Advice that wraps around method execution to measure and log
     * execution time.
     *
     * @param pjp the join point representing the method execution
     * @return the result of the method execution
     * @throws Throwable if the method execution throws an exception
     */
    @Around("@annotation(com.ford.gpcse.aop.TrackExecutionTime)")
    public Object trackTime(ProceedingJoinPoint pjp) throws Throwable {
        MethodSignature methodSignature = (MethodSignature) pjp.getSignature();

        // Get intercepted method details
        String className = methodSignature.getDeclaringType().getSimpleName();
        String methodName = methodSignature.getName();
        final StopWatch stopWatch = new StopWatch();

        // Measure method execution time
        stopWatch.start();
        Object result = pjp.proceed();  // Proceed with method execution
        stopWatch.stop();

        // Log method execution time
        log.info("Execution time of {}.{} :: {} ms", className, methodName, stopWatch.getTotalTimeMillis());

        return result;  // Return the result of the method
    }

}
