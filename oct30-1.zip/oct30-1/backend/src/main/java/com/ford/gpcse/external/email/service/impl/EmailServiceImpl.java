package com.ford.gpcse.external.email.service.impl;

import com.ford.gpcse.external.email.service.EmailService;
import com.ford.gpcse.model.Email;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

/**
 * Implementation of the EmailService interface for sending emails.
 * This class uses Spring's JavaMailSender to facilitate email sending
 * functionality, handling both plain text and HTML emails.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class EmailServiceImpl implements EmailService {

    private final JavaMailSender emailSender; // JavaMailSender for sending emails

    /**
     * Sends an email using the provided Email object.
     *
     * @param email the Email object containing the necessary details to send the email
     * @return true if the email was sent successfully, false otherwise
     */
    @Override
    public boolean sendMail(Email email) {
        return true;
//        try {
//            // Create a new MimeMessage
//            MimeMessage message = emailSender.createMimeMessage();
//            MimeMessageHelper helper = new MimeMessageHelper(message, true); // true for multipart (attachments)
//
//            // Set email properties
//            helper.setTo(email.getTo().toArray(String[]::new)); // Set recipients
//            helper.setSubject(email.getSubject()); // Set subject
//            helper.setText(email.getBody(), true); // Set body (HTML content)
//            helper.setFrom(email.getFrom()); // Set sender's email address
//
//            // Send the email
//            emailSender.send(message);
//            return true; // Email sent successfully
//        } catch (MessagingException e) {
//            // Log the error and return false
//            log.error("Error occurred while sending email: {}", e.getMessage());
//            return false; // Email sending failed
//        }
    }
}
