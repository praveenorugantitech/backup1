package com.ford.gpcse.external.vsem.service;

import com.ford.gpcse.model.TokenResponse;

public interface AuthService {
    TokenResponse fetchToken();
}
