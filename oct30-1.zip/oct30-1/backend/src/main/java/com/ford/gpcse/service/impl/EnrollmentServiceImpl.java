package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.SupplierEnrollmentRequest;
import com.ford.gpcse.exception.UnableToSendEmailNotification;
import com.ford.gpcse.external.email.service.EmailService;
import com.ford.gpcse.model.Email;
import com.ford.gpcse.service.EnrollmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Implementation of the EnrollmentService interface.
 * This service handles supplier enrollment requests, primarily by sending emails.
 */
@Service
@RequiredArgsConstructor
public class EnrollmentServiceImpl implements EnrollmentService {
    // Email service for sending emails
    private final EmailService emailService;

    /**
     * Handles the supplier enrollment process.
     *
     * @param supplierEnrollmentRequest the request containing supplier enrollment details
     * @return a message indicating the status of the enrollment
     * @throws UnableToSendEmailNotification if there is an error sending the email
     */
    @Override
    public String supplierEnrollment(SupplierEnrollmentRequest supplierEnrollmentRequest) {
        // Attempt to send the enrollment email
        if(sendSupplierEnrollmentEmail(supplierEnrollmentRequest)) {
            return "Your request has been submitted.";
        } else {
            // Throw an exception if email sending fails
            throw new UnableToSendEmailNotification("Your request not submitted due to SMTP failure");
        }
    }

    /**
     * Constructs and sends the supplier enrollment email.
     *
     * @param supplierEnrollmentRequest the request containing supplier details
     * @return true if the email was sent successfully, false otherwise
     */
    private boolean sendSupplierEnrollmentEmail(SupplierEnrollmentRequest supplierEnrollmentRequest) {
        // Create the email body with supplier information
        String emailBody = "<HTML><HEAD></HEAD><BODY>" +
                "<P>User ID: " + supplierEnrollmentRequest.getUserId() + "</P>" +
                "<P>First Name: " + supplierEnrollmentRequest.getFirstName() + "</P>" +
                "<P>Last Name: " + supplierEnrollmentRequest.getLastName() + "</P>" +
                "<P>Email Address: " + supplierEnrollmentRequest.getEmailAddress() + "</P>" +
                "<P>Comments: " + supplierEnrollmentRequest.getComments() + "</P>" +
                "</Body></HTML>";

        // Build the email object with necessary details
        Email email = Email.builder()
                .from("") // Sender's email address
                .to(List.of("")) // List of recipient email addresses
                .subject("Firmware User") // Subject of the email
                .body(emailBody) // Body of the email
                .build();

        // Send the email using the email service and return the result
        return emailService.sendMail(email);
    }
}
