package com.ford.gpcse.external.email.service;

import com.ford.gpcse.model.Email;
import org.springframework.stereotype.Service;

@Service
public interface EmailService {

    boolean sendMail(Email email);

}
