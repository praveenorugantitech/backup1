package com.ford.gpcse.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCMR40_RGN_BUILT")
public class RgnBuilt {
    @Id
    @Column(name = "PCMR40_RGN_BUILT_C", nullable = false)
    private String rgnBuiltC;

    @Column(name = "PCMR40_RGN_BUILT_X", nullable = false)
    private String rgnBuiltX;


    @Column(name = "PCMR40_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR40_CREATE_S", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR40_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR40_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;

}
