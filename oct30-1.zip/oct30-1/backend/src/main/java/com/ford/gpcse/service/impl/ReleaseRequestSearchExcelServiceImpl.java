package com.ford.gpcse.service.impl;


import com.ford.gpcse.bo.ReleaseRequestSearchInput;
import com.ford.gpcse.entity.ModuleType;
import com.ford.gpcse.entity.PgmReleaseRequest;
import com.ford.gpcse.entity.ProgramDescription;
import com.ford.gpcse.entity.ReleaseRequest;
import com.ford.gpcse.repository.ReleaseRequestRepository;
import com.ford.gpcse.service.ReleaseRequestSearchExcelService;
import jakarta.persistence.criteria.*;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ReleaseRequestSearchExcelServiceImpl implements ReleaseRequestSearchExcelService {

    private final ReleaseRequestRepository releaseRequestRepository;
    private static final String[] HEADERS = {
            "ID", "MY", "Prog.", "Engine", "Owner", "Status", "Module",
            "Priority", "Priority Description", "Reason", "R Level",
            "Coordination", "Strategy", "Back Compat", "Build Level",
            "Cal Release Date", "Project Control", "Previous Concern",
            "Release Usage", "Release Title", "Cal In CCM",
            "Sw Coordination", "Coordination Details", "Alert Req",
            "Alert Details", "Change Usage", "Change Usage Details",
            "Build Start Date", "Supplier VBF Delivery Date",
            "App DR Eng Cds", "Cal Eng Cds", "Cal Rel Support Cds",
            "Hardware Part Number", "Ipf Inst Part Number",
            "Service Part Number", "Concern", "Alert", "Created"
    };

    @Override
    public ByteArrayInputStream exportReleaseRequestDetails(ReleaseRequestSearchInput releaseRequestSearchInput) throws IOException {
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {

            Sheet releaseRequestSheet = workbook.createSheet("ReleaseRequest");

            createHeaderRowForReleaseRequest(releaseRequestSheet);

            Specification<ReleaseRequest> releaseRequestSpec = filterByCriteria(releaseRequestSearchInput.getId(), releaseRequestSearchInput.getModuleTypeCode(), releaseRequestSearchInput.getCalibrationLevel(), releaseRequestSearchInput.getModelYear(), releaseRequestSearchInput.getProgram(), releaseRequestSearchInput.getEngine(), releaseRequestSearchInput.getStatus(), releaseRequestSearchInput.getOwner());

            List<ReleaseRequest> releaseRequests = releaseRequestRepository.findAll(releaseRequestSpec);

            createDataRowForReleaseRequest(releaseRequests, releaseRequestSheet);


            workbook.write(out);
            return new ByteArrayInputStream(out.toByteArray());
        }
    }

    private void createDataRowForReleaseRequest(List<ReleaseRequest> releaseRequests, Sheet releaseRequestSheet) {
        // Write the results to the sheet
        int rowNum = 1;
        for (ReleaseRequest relReq : releaseRequests) {
            Row row = releaseRequestSheet.createRow(rowNum++);

            // Fill in the cell values for the row
            int curCol = 0; // Reset column index for each row
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getRelReqK())); // ID
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getProgramReleaseRequests().get(0).getProgramDescription().getMdlYrR())); // Model Year
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getProgramReleaseRequests().get(0).getProgramDescription().getPgmN())); // Program Code
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getProgramReleaseRequests().get(0).getProgramDescription().getEngN())); // Engine
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getCreateUserC())); // Create User Cds
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getStatusC())); // Status
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getModuleType().getModuleTypC())); // Module Type Code
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getPrtyC())); // Priority Code
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getPrtyDtlX())); // Priority Description
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getRelReqReasonX())); // Reason
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getCalRLevelR())); // Calibration Level
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getCoordReqF())); // Is Coordination Required
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getStratRelC())); // Strategy Release Code
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getBackCompatF())); // Is Backward Compatible
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getBldLvlC())); // Build Level Code
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getCalRelY())); // Calibration Release Date
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getProjectControlC())); // Project Control Eng Cds
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getPrevConcernC())); // Previous Concern
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getReleaseUsage().getRelUsgC())); // Release Usage Code
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getReleaseTitleX())); // Release Title
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getCalInCcmF())); // Is Calibration in CCM
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getAddHwSwCoordF())); // Has Hardware Software Coordination
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getHwSwCoordDetailX())); // Hardware Software Coordination Details
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getAlertRequiredF())); // Is Alert Required
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getAlertDetailX())); // Alert Details
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getRollPartChangeUsageF())); // Change Usage
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getRollPartChangeUsageX())); // Change Usage Details
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getBuildStartY())); // Build Start Date
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getSuppVbfDelY())); // Supplier VBF Delivery Date
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getAppDrEngC())); // Application DR Engineer Cds
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getCalEngC())); // Calibration Engineer Cds
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getCalRelSupportC())); // Calibration Release Support Cds
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getHardwarePartR())); // Hardware Part Number
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getIpfInstalledPartR())); // IPF Installed Part Number
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getServicePartR())); // Service Part Number
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getConcernC()));// Concern
            row.createCell(curCol++).setCellValue(getSafeValue(relReq.getAlertC())); // Alert
            row.createCell(curCol).setCellValue(getSafeValue(relReq.getCreateS())); // Create Date
        }

    }

    private void createHeaderRowForReleaseRequest(Sheet releaseRequestSheet) {
        Row headerRow = releaseRequestSheet.createRow(0);
        headerRow.setHeightInPoints(20);

        // Create a font for the header and set it to bold
        Workbook workbook = releaseRequestSheet.getWorkbook();
        CellStyle headerStyle = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        headerStyle.setFont(font);
        // Create static headers first
        int columnIndex = 0;
        for (String header : HEADERS) {
            Cell cell = headerRow.createCell(columnIndex);
            cell.setCellValue(header);
            cell.setCellStyle(headerStyle); // Apply the bold style

            // Set the column width based on the header length
            int columnWidth = header.length() * 512;
            releaseRequestSheet.setColumnWidth(columnIndex, columnWidth);
            columnIndex++;
        }
    }

    public static Specification<ReleaseRequest> filterByCriteria(
            Long id,
            String moduleTypeCode,
            String calibrationLevel,
            String modelYear,
            String program,
            String engine,
            String status,
            String owner) {

        return (Root<ReleaseRequest> root, CriteriaQuery<?> query, CriteriaBuilder cb) -> {
            Predicate predicate = cb.conjunction();

            if (id != null && id != -1) {
                predicate = cb.and(predicate, cb.equal(root.get("relReqK"), id));
            }

            if (calibrationLevel != null && !calibrationLevel.isBlank()) {
                predicate = cb.and(predicate, cb.like(root.get("calRLevelR"), "%" + calibrationLevel + "%"));
            }

            if (status != null && !status.isBlank()) {
                predicate = cb.and(predicate, cb.like(root.get("statusC"), "%" + status + "%"));
            }

            if (owner != null && !owner.isBlank()) {
                predicate = cb.and(predicate, cb.like(root.get("createUserC"), "%" + owner + "%"));
            }

            // Handle moduleType and other criteria
            if (moduleTypeCode != null && !moduleTypeCode.isBlank() ||
                    modelYear != null || program != null || engine != null) {

                Join<ReleaseRequest, PgmReleaseRequest> join = root.join("programReleaseRequests");
                Join<PgmReleaseRequest, ProgramDescription> programJoin = join.join("programDescription");
                Join<ReleaseRequest, ModuleType> moduleJoin = root.join("moduleType");

                Predicate subPredicate = cb.conjunction();

                if (moduleTypeCode != null && !moduleTypeCode.isBlank()) {
                    subPredicate = cb.and(subPredicate, cb.like(moduleJoin.get("moduleTypC"), "%" + moduleTypeCode + "%"));
                }

                if (modelYear != null && !modelYear.isBlank()) {
                    subPredicate = cb.and(subPredicate, cb.like(programJoin.get("mdlYrR"), "%" + modelYear + "%"));
                }

                if (program != null && !program.isBlank()) {
                    subPredicate = cb.and(subPredicate, cb.like(programJoin.get("pgmN"), "%" + program + "%"));
                }

                if (engine != null && !engine.isBlank()) {
                    subPredicate = cb.and(subPredicate, cb.like(programJoin.get("engN"), "%" + engine + "%"));
                }

                predicate = cb.and(predicate, subPredicate);
            }

            return predicate;
        };
    }

    private static String getSafeValue(Object value) {
        return value != null ? value.toString() : "";
    }
}
