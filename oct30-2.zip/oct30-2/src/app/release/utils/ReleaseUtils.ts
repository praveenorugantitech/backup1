import Swal from "sweetalert2";

export class ReleaseUtils {
  static showErrorSweetAlert(title: string, text: string) {
    Swal.fire({
      icon: "error",
      title: title,
      html: text,
      confirmButtonColor: "#00467f",
    });
  }

  static trim(s: string): string {
    return s.trim();
  }

  static isPartNumber(s: string): boolean {
    const regularExpression =
      /^[a-hj-np-z0-9]{4,8}(\-)[a-z0-9]{5,6}(\-)[a-hj-npr-vx-z]{1,1}[a-z0-9]{1,7}$/i;
    return regularExpression.test(ReleaseUtils.trim(s));
  }

  static validateFieldNoHtmTags(
    frmField: string,
    frmFieldName: string,
    minLength: number,
    maxLength?: number
  ): string {
    let res = "";
    const val = ReleaseUtils.trim(frmField);

    res += ReleaseUtils.checkFieldMinMaxLength(
      val,
      frmFieldName,
      minLength,
      maxLength
    );

    if (val.length > 0 && ReleaseUtils.hasGreaterThanOrLessThan(val)) {
      res +=
        "* " +
        frmFieldName +
        " cannot contain HTML tags (no > or < characters).";
    }

    return res;
  }

  static checkFieldMinMaxLength(
    val: string,
    frmFieldName: string,
    minLength: number,
    maxLength?: number
  ): string {
    let res = "";
    if (val.length < minLength) {
      res +=
        "* " +
        frmFieldName +
        " must be at least " +
        minLength +
        " characters long.";
    }
    if (maxLength && val.length > maxLength) {
      res +=
        "* " +
        frmFieldName +
        " must be no more than " +
        maxLength +
        " characters long.";
    }
    return res;
  }

  static hasGreaterThanOrLessThan(val: string): boolean {
    return val.includes("<") || val.includes(">");
  }

  // Part Number Validation: TestPartNumber function
  static TestPartNumber(partNumber: string, releaseType: string): boolean {
    // Regular expression for part number validation
    let regularExpression =
      /^DS[a-hj-np-z0-9]{4,8}(\-)[a-z0-9]{5,6}(\-)[a-hj-npr-vx-z]{1,1}[a-z0-9]{1,7}$/i;

    // If releaseType is 'PDX', use PX prefix
    if (releaseType === "PDX") {
      regularExpression =
        /^PX[a-hj-np-z0-9]{4,8}(\-)[a-z0-9]{5,6}(\-)[a-hj-npr-vx-z]{1,1}[a-z0-9]{1,7}$/i;
    }

    return regularExpression.test(partNumber.trim());
  }

  static ValidateAssemblyBasePartNumberFromModuleType(
    pModuleTypeCode: string,
    pPn: string
  ): string {
    if (!ReleaseUtils.isPartNumber(pPn)) {
      return "'" + pPn + "' is not a valid part number.";
    }
    const strTmp = pPn.toUpperCase();
    let sReturn = "";

    const relTypToBaseAssembly = [
      ['PCM', '-12A650-'],
      ['BCCM', '-10B689-'],
      ['BCCMB', '-10D678-'],
      ['BCCMI', '-10D751-'],
      ['BECM', '-10B687-'],
      ['TRCM', '-7E096-'],
      ['VCM', '-14J020-'],
      ['GSM', '-7E453-'],
      ['HPCM', '-7P120-'],
      ['TCM', '-12B565-'],
      ['DCU', '-5H298-'],
      ['GDM', '-12C550-'],
      ['DLCM', '-7P238-'],
      ['PMSEN', '-5L239-'],
      ['NOXTP', '-5L234-'],
      ['NOXFG', '-5K202-'],
      ['NOXMB', '-5L299-'],
      ['UCLS', '-5J242-'],
      ['GPCM', '-12B533-'],
      ['TCCM', '-7H417-'],
      ['AWDCH', '-7S008-']
    ];

    for (let i = 0; i < relTypToBaseAssembly.length; i++) {
      if (relTypToBaseAssembly[i][0] === pModuleTypeCode) {
        for (let x = 1; x < relTypToBaseAssembly[i].length; x++) {
          const index = strTmp.indexOf(relTypToBaseAssembly[i][x]);
          if (index === -1) {
            sReturn +=
              "* Part number '" +
              strTmp +
              "' has an invalid base. Must be " +
              relTypToBaseAssembly[i][x] +
              " for this module type.";
          } else {
            return ""; // Valid base found
          }
        }
      }
    }

    return sReturn; // Return any accumulated errors
  }


static validateSblBasePartNumber(
    pModuleTypeCode: string,
    pPn: string
  ): string {
    if (!ReleaseUtils.isPartNumber(pPn)) {
      return "'" + pPn + "' is not a valid part number.";
    }
    const strTmp = pPn.toUpperCase();
    let sReturn = "";

    const relTypToBaseAssembly = [
      ["AWDCH", "-14H299-"],
      ["BCCM", "-14F478-"],
      ["BCCMB", "-10D683-"],
      ["BCCMI", "-10D747-"],
      ["BECM", "-14C200-"],
      ["DCU", "-14G252-"],
      ["GDM", "-12C554-"],
      ["DLCM", "-14G578-"],
      ["GPCM", "-14D611-"],
      ["GSM", "-14C563-"],
      ["HPCM", "-14G071-"],
      ["NOXFG", "-14F555-"],
      ["NOXMB", "-14H067-"],
      ["NOXTP", "-14G267-"],
      ["PCM", "-14C273-"],
      ["PMSEN", "-14G338-"],
      ["TCCM", "-14C368-"],
      ["TCM", "-14C339-"],
      ["TRCM", "-14G174-"],
      ["VCM", "-14J027-"],
      ["UCLS", "-5M205-"],
    ];

    for (let i = 0; i < relTypToBaseAssembly.length; i++) {
      if (relTypToBaseAssembly[i][0] === pModuleTypeCode) {
        for (let x = 1; x < relTypToBaseAssembly[i].length; x++) {
          const index = strTmp.indexOf(relTypToBaseAssembly[i][x]);
          if (index === -1) {
            sReturn +=
              "* Part number '" +
              strTmp +
              "' has an invalid base. Must be " +
              relTypToBaseAssembly[i][x] +
              " for this module type.";
          } else {
            return ""; // Valid base found
          }
        }
      }
    }

    return sReturn; // Return any accumulated errors
  }
}
