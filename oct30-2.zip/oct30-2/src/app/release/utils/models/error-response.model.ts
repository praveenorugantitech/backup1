export interface ErrorResponse {
    status: string; 
    message: string;
    details?: Details; 
}

export interface Details {
    uri: string;
    timestamp: string;
}
