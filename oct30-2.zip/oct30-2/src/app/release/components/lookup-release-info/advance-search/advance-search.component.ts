import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { ReleaseService } from "../../../utils/services/release.service";
@Component({
  selector: "app-advance-search",
  templateUrl: "./advance-search.component.html",
  styleUrl: "./advance-search.component.scss",
})
export class AdvanceSearchComponent implements OnInit {
  constructor(
    private router: Router,
    private releaseService: ReleaseService
  ) {}

  ngOnInit() {
  
  }

  setTitle(title: string) {
   
  }
}
