import { Component, OnDestroy, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { ReleaseService } from "../../../../utils/services/release.service";
import { Subject } from "rxjs";
import { ErrorResponse } from "../../../../utils/models/error-response.model";
import { ReleaseUtils } from "../../../../utils/ReleaseUtils";
import { takeUntil } from "rxjs/operators";
import { HttpErrorResponse } from "@angular/common/http";
import { exportToExcelPostModel } from "../../../../utils/models/export-excel.model";
@Component({
  selector: "app-program",
  templateUrl: "./program.component.html",
  styleUrl: "./program.component.scss",
})
export class ProgramComponent implements OnInit, OnDestroy {
  searchTerm: string = "";
  selectedPrograms: string[] = [];
  programs: string[] = [];
  programKeys: string[] = [];
  filteredProgramKeys: string[] = [];
  tempShowTable: boolean = false;
  firmwareRecords: any[] = [];
  selectedRecords: Set<string> = new Set();
  private unsubscribe$ = new Subject<void>();
  selectAllChecked: boolean = false;

  constructor(private router: Router, private releaseService: ReleaseService) {}

  ngOnInit() {
    // Reset state on component initialization
    this.resetState();
    this.fetchPrograms();
  }

  private resetState() {
    this.selectedPrograms = [];
    this.firmwareRecords = [];
    this.tempShowTable = false;
    this.selectAllChecked = false;
    this.selectedRecords.clear();
  }

  fetchPrograms() {
    this.releaseService.getPrograms().subscribe((data) => {
      this.programs = data.map(
        (program) =>
          `${program.mdlYrR}, ${program.pgmN}, ${program.platN}, ${program.engN}, ${program.transN}`
      );
      this.programKeys = data.map((program) => `${program.programKey}`);
    });
  }

  // Filter the programs based on the search term
  filteredPrograms() {
    // If the search term is empty, return all programs
    if (!this.searchTerm) {
      return this.programs;
    }
    // Otherwise, filter the programs
    return this.programs.filter((program) =>
      program.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }
  // Capture selected programs and filter their corresponding program keys
  onProgramSelect(event: any) {
    const selectedOptions = event.target.selectedOptions;
    this.selectedPrograms = [];

    // Collect selected programs
    for (let i = 0; i < selectedOptions.length; i++) {
      this.selectedPrograms.push(selectedOptions[i].value);
    }

    // Filter corresponding program keys
    this.filteredProgramKeys = this.selectedPrograms
      .map((selectedProgram) => {
        const index = this.programs.indexOf(selectedProgram);
        return this.programKeys[index];
      })
      .filter((key) => key !== undefined);
  }

  // Event handler for OK button
  onOkClick() {
    this.releaseService
      .getFirmwareDetailsByPrograms(this.filteredProgramKeys)
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe({
        next: (response: any) => {
          this.firmwareRecords = Array.isArray(response) ? response : [];
          this.tempShowTable = true;
        },
        error: (error: HttpErrorResponse) => this.handleError(error),
      });
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage = "An unexpected error occurred.";

    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message; // Client-side error
    } else if (typeof error.error === "string") {
      try {
        const errorResponse: ErrorResponse = JSON.parse(error.error);
        errorMessage = errorResponse.message || errorMessage;
      } catch {
        console.error("Error parsing response");
      }
    } else if (error.error?.message) {
      errorMessage = error.error.message; // Server-side error
    }

    ReleaseUtils.showErrorSweetAlert("Error", errorMessage);
  }

  // Event handler for Cancel button
  onCancelClick() {
    this.resetState();
    window.scrollTo({ top: 0, behavior: "smooth" });
    this.router.navigate(["/"]);
  }

  toggleSelectAll(event: Event) {
    const isChecked = (event.target as HTMLInputElement).checked;
    this.selectAllChecked = isChecked;

    if (isChecked) {
      this.firmwareRecords.forEach((record) => {
        this.selectedRecords.add(record.assemblyPN);
      });
    } else {
      this.selectedRecords.clear();
    }
  }

  isRecordSelected(assemblyPN: string): boolean {
    return this.selectedRecords.has(assemblyPN);
  }

  toggleRecordSelection(assemblyPN: string) {
    if (this.selectedRecords.has(assemblyPN)) {
      this.selectedRecords.delete(assemblyPN);
    } else {
      this.selectedRecords.add(assemblyPN);
    }
  }

  exportToXML() {
    const partNumbers = Array.from(this.selectedRecords);
    const dataToSend: exportToExcelPostModel = new exportToExcelPostModel();
    dataToSend.partNumbers = partNumbers;
    dataToSend.fileName = "FirmwareExport.xml";

    this.releaseService.exportPartsToXML(dataToSend).subscribe(
      (response) => {
        const blob = new Blob([response], {
          type: "text/xml",
        });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "FirmwareExport.xml";
        a.click();
        window.URL.revokeObjectURL(url);
      },
      (error) => {
        console.error("Error exporting parts to xml:", error);
      }
    );
  }

  exportToExcel() {
    const partNumbers = Array.from(this.selectedRecords);
    this.releaseService.exportPartsToExcel(partNumbers).subscribe(
      (response) => {
        const blob = new Blob([response], {
          type: "application/vnd.openxmlformats",
        });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "FirmwareExport.xlsx";
        a.click();
        window.URL.revokeObjectURL(url);
      },
      (error) => {
        console.error("Error exporting parts to excel:", error);
      }
    );
  }
  ngOnDestroy() {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }
}
