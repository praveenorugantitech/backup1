import { HttpErrorResponse } from "@angular/common/http";
import { Component, OnInit } from "@angular/core";
import { ReleaseService } from "../../../utils/services/release.service";
import Swal from "sweetalert2";
import { ErrorResponse } from "../../../utils/models/error-response.model";
import {
  AddPblData,
  PblModel,
  FetchPartDetails,
  ReplacePblPutModel,
  PartFirmware,
  PartFirmwareRecord,
} from "../../../utils/models/pbl.model";
import { ReleaseUtils } from "../../../utils/ReleaseUtils";
import { Router } from "@angular/router";
import { ModuleTypesOptionsModel } from "../../../utils/models/shared.model";

@Component({
  selector: "app-add-pbl",
  templateUrl: "./add-pbl.component.html",
  styleUrl: "./add-pbl.component.scss",
})
export class AddPblComponent implements OnInit {
  constructor(private router: Router, private releaseService: ReleaseService) {}
  firmwareRecords: any[] = [];
  selectedRecords: Set<string> = new Set();
  displayFirmDetails: boolean = false;
  pblData: PblModel = new PblModel();
  moduleTypeOptions: Array<ModuleTypesOptionsModel> = new Array();

  filteredOptionsModuleType: Array<ModuleTypesOptionsModel> = new Array();

  ngOnInit() {
    this.pblData.releaseType = "replace_pbl";
    this.getModuleTypes();
  }

  filterOptions() {
    if (this.pblData.moduleTypeName) {
      this.filteredOptionsModuleType = this.moduleTypeOptions.filter((option) =>
        option.moduleTypeName
          .toLowerCase()
          .includes(String(this.pblData.moduleTypeName.toLowerCase()))
      );
    } else {
      this.filteredOptionsModuleType = this.moduleTypeOptions;
    }
  }

  getModuleTypes() {
    try {
      this.releaseService.getModuleTypes().subscribe((res) => {
        if (res.length > 0) {
          this.moduleTypeOptions = res;
          this.filterOptions();
        } else {
          console.error(
            "Something went wrong while fetching the module types."
          );
        }
      });
    } catch (err) {
      console.error(err);
    }
  }
  validatePBLData() {
    const { releaseType, moduleTypeCode, currentPbl, newPbl } = this.pblData;

    let errorMessages = [];

    // Check required fields
    if (!releaseType) {
      errorMessages.push("* Select Release Type.");
    }
    if (!moduleTypeCode) {
      errorMessages.push("* Select Module Type.");
    }

    if (!newPbl) {
      errorMessages.push("* New PBL Required.");
    } else {
      // Validate newPbl using the new function
      const newPblError = ReleaseUtils.validateFieldNoHtmTags(
        newPbl,
        "New PBL:",
        1
      );
      if (newPblError) {
        errorMessages.push(newPblError);
      }
    }

    if (releaseType === "replace_pbl") {
      if (!currentPbl) {
        errorMessages.push("* Current PBL Required.");
      } else {
        // Validate currentPbl using the new function
        const currentPblError = ReleaseUtils.validateFieldNoHtmTags(
          currentPbl,
          "Current PBL:",
          1
        );
        if (currentPblError) {
          errorMessages.push(currentPblError);
        }
      }
    }

    // If there are any error messages, display them using SweetAlert
    if (errorMessages.length > 0) {
      const fullMessage =
        errorMessages.join("<br>") +
        "<br><br>Please correct the issues listed above and try again.";
      ReleaseUtils.showErrorSweetAlert("Error", fullMessage);
      return false;
    }

    return true;
  }

  addNewPBL(pblData: AddPblData) {
    this.releaseService.addPBL(pblData).subscribe({
      next: (response: any) => {
        const successMessage = response;
        Swal.fire({
          icon: "success",
          title: "Success",
          text: successMessage,
          confirmButtonColor: "#00467f",
        }).then(() => {
          this.router.navigate(["/"]);
        });
      },
      error: (error: any) => {
        // Parse the error string
        let errorResponse: ErrorResponse;
        try {
          errorResponse = JSON.parse(error.error);
        } catch (e) {
          errorResponse = {
            status: "error",
            message: "An unexpected error occurred.",
          };
        }

        const errorMessage =
          errorResponse.message || "An unexpected error occurred.";

        ReleaseUtils.showErrorSweetAlert("Error", `${errorMessage}`);
      },
    });
  }

  fetchPartsByFirmware(firmwareData: FetchPartDetails) {
    this.releaseService.getPartsByFirmware(firmwareData).subscribe({
      next: (response: any) => {
        this.displayFirmDetails = true;
        this.firmwareRecords = Array.isArray(response) ? response : [];
      },
      error: (error: HttpErrorResponse) => {
        let errorMessage = "An unexpected error occurred.";

        // Check if the error has a response and is in JSON format
        if (error.error instanceof ErrorEvent) {
          // Client-side error
          errorMessage = error.error.message;
        } else if (error.error && typeof error.error === "string") {
          // Attempt to parse server-side error if it is a string
          try {
            const errorResponse: ErrorResponse = JSON.parse(error.error);
            errorMessage = errorResponse.message || errorMessage;
          } catch (e) {
            // If parsing fails, fall back to the default message
            console.error("Error parsing response:", e);
          }
        } else if (error.error && error.error.message) {
          // Directly use the error message if it's an object
          errorMessage = error.error.message;
        }

        ReleaseUtils.showErrorSweetAlert("Error", errorMessage);
      },
    });
  }

  replacePBL() {
    const { moduleTypeCode, newPbl } = this.pblData;

    const dataToSend: ReplacePblPutModel = {
      newPbl,
      moduleTypeCode,
      createUser: "DSADASH1",
      lastUpdateUser: "DSADASH1",
      partNumbers: Array.from(this.selectedRecords),
    };
    this.releaseService.replacePBL(dataToSend).subscribe({
      next: (response: any) => {
        const successMessage = response;
        Swal.fire({
          icon: "success",
          title: "Success",
          text: successMessage,
          confirmButtonColor: "#00467f",
        }).then(() => {
          this.router.navigate(["/"]);
        });
      },
      error: (error: any) => {
        // Parse the error string
        let errorResponse: ErrorResponse;
        try {
          errorResponse = JSON.parse(error.error);
        } catch (e) {
          errorResponse = {
            status: "error",
            message: "An unexpected error occurred.",
          };
        }

        const errorMessage =
          errorResponse.message || "An unexpected error occurred.";

        ReleaseUtils.showErrorSweetAlert("Error", `${errorMessage}`);
      },
    });
  }

  addPBL() {
    if (this.validatePBLData()) {
      const { releaseType, moduleTypeCode, currentPbl, newPbl } = this.pblData;
      if (releaseType === "new_pbl") {
        const dataToSend: AddPblData = {
          newPbl,
          moduleTypeCode,
          createUser: "DSADASH1",
          lastUpdateUser: "DSADASH1",
        };
        this.addNewPBL(dataToSend);
      }
      if (releaseType === "replace_pbl") {
        const dataToSend: FetchPartDetails = {
          newPbl,
          currentPbl,
        };
        this.fetchPartsByFirmware(dataToSend);
      }
    }
  }

  cancelSubmit() {
    this.pblData = new PblModel();
    this.pblData.releaseType = "replace_pbl";
    window.scrollTo({ top: 0, behavior: "smooth" });
    this.router.navigate(["/"]);
  }

  // Method to toggle selection of all checkboxes
  toggleSelectAll(event: Event) {
    const isChecked = (event.target as HTMLInputElement).checked;
    if (isChecked) {
      // Select all
      this.firmwareRecords.forEach((record) => {
        this.selectedRecords.add(record.assemblyPN); // Use a unique identifier
      });
    } else {
      // Deselect all
      this.selectedRecords.clear();
    }
  }

  // Method to check if a record is selected
  isRecordSelected(assemblyPN: string): boolean {
    return this.selectedRecords.has(assemblyPN);
  }

  // Method to toggle individual checkbox selection
  toggleRecordSelection(assemblyPN: string) {
    if (this.selectedRecords.has(assemblyPN)) {
      this.selectedRecords.delete(assemblyPN); // Deselect
    } else {
      this.selectedRecords.add(assemblyPN); // Select
    }
  }

  exportToExcel() {
    const partNumbers = this.firmwareRecords.map((record) => record.assemblyPN);

    this.releaseService.exportPartsToExcel(partNumbers).subscribe(
      (response) => {
        const blob = new Blob([response], {
          type: "application/vnd.openxmlformats",
        });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "FirmwareExport.xlsx"; // File name for download
        a.click();
        window.URL.revokeObjectURL(url); // Cleanup
      },
      (error) => {
        console.error("Error exporting parts:", error);
      }
    );
  }

  // Method to get unique categories from the firmware records
  getUniqueCategories(record: PartFirmwareRecord): string[] {
    const categories = record.partFirmwares.map(
      (firmware: PartFirmware) => firmware.firmwareCatgN
    );
    return Array.from(new Set(categories)); // Return unique categories
  }

  // Method to get firmware by category
  getFirmwareByCategory(
    record: PartFirmwareRecord,
    category: string
  ): PartFirmware[] {
    return record.partFirmwares.filter(
      (firmware: PartFirmware) => firmware.firmwareCatgN === category
    );
  }
}
