import { Component, OnInit } from "@angular/core";
import { ReleaseService } from "../../../utils/services/release.service";

import {
  SblModel,
  AddSblPostModel,
  ReplaceSblPutModel,
} from "../../../utils/models/sbl.model";
import {
  MicroTypesOptionModel,
  ModuleTypesOptionsModel,
  SupplierOptionsModel,
} from "../../../utils/models/shared.model";
import { ErrorResponse } from "../../../utils/models/error-response.model";
import Swal from "sweetalert2";
import { Router } from "@angular/router";
import { ReleaseUtils } from "../../../utils/ReleaseUtils";

@Component({
  selector: "app-add-sbl",
  templateUrl: "./add-sbl.component.html",
  styleUrl: "./add-sbl.component.scss",
})
export class AddSblComponent implements OnInit {
  constructor(private router: Router, private releaseService: ReleaseService) {}

  sblData: SblModel = new SblModel();
  supplierOptions: Array<SupplierOptionsModel> = new Array();
  moduleTypeOptions: Array<ModuleTypesOptionsModel> = new Array();
  microTypeOptions: Array<MicroTypesOptionModel> = new Array();

  filteredOptionsSupplier: Array<SupplierOptionsModel> = new Array();
  filteredOptionsModuleType: Array<ModuleTypesOptionsModel> = new Array();
  filteredOptionsMicroType: Array<MicroTypesOptionModel> = new Array();

  ngOnInit() {
    this.initializeAndSetupData();
  }

  initializeAndSetupData() {
    this.getSupplierData();
    this.getModuleTypes();
  }

  filterOptions(changeOpt: String) {
    if (changeOpt === "supplier") {
      if (this.sblData.supplierName) {
        this.filteredOptionsSupplier = this.supplierOptions.filter((option) =>
          option.supplierName
            ?.toLowerCase()
            .includes(String(this.sblData.supplierName.toLowerCase()))
        );
      } else {
        this.filteredOptionsSupplier = this.supplierOptions;
      }
    }
    if (changeOpt === "module_type") {
      if (this.sblData.moduleTypeName) {
        this.filteredOptionsModuleType = this.moduleTypeOptions.filter(
          (option) =>
            option.moduleTypeName
              .toLowerCase()
              .includes(String(this.sblData.moduleTypeName.toLowerCase()))
        );
      } else {
        this.filteredOptionsModuleType = this.moduleTypeOptions;
      }
    }

    if (changeOpt === "micro_type") {
      if (this.sblData.microTypeName) {
        this.filteredOptionsMicroType = this.microTypeOptions.filter((option) =>
          option.microTypeName
            .toLowerCase()
            .includes(String(this.sblData.microTypeName.toLowerCase()))
        );
      } else {
        this.filteredOptionsMicroType = this.microTypeOptions;
      }
    }
  }

  getSupplierData() {
    try {
      this.releaseService.getSupplier().subscribe((res) => {
        if (res.length > 0) {
          this.supplierOptions = res;
          this.filterOptions("supplier");
        } else {
          console.error(
            "Something went wrong while fetching the suppliers types."
          );
        }
      });
    } catch (err) {
      console.error(err);
    }
  }

  getModuleTypes() {
    try {
      this.releaseService.getModuleTypes().subscribe((res) => {
        if (res.length > 0) {
          this.moduleTypeOptions = res;
          this.filterOptions("module_type");
        } else {
          console.error(
            "Something went wrong while fetching the module types."
          );
        }
      });
    } catch (err) {
      console.error(err);
    }
  }

  getMicroTypes(moduleTypeCode: string) {
    if (moduleTypeCode) {
      try {
        this.releaseService.getMicroTypes(moduleTypeCode).subscribe(
          (res) => {
            if (res.length > 0) {
              this.microTypeOptions = res;
              this.filterOptions("micro_type");
            } else {
              console.error(
                "Something went wrong while fetching the micro types."
              );
              this.resetMicroType();
            }
          },
          (error) => {
            console.error("Error fetching micro types:", error);
            this.resetMicroType(); // Reset on error
          }
        );
      } catch (err) {
        console.error(err);
        this.resetMicroType(); // Reset in case of an exception
      }
    }
  }

  resetMicroType() {
    this.sblData.microTypeName = ""; // Resetting the micro type
    this.microTypeOptions = []; // Clear micro type options as well
  }

  handleModuleType(moduleTypeName: string) {
    // Reset micro type name when a new module type is selected
    this.sblData.microTypeName = ""; // Resetting the micro type
    this.microTypeOptions = [];

    if (!moduleTypeName) {
      this.microTypeOptions = []; // Clear micro type options
    } else {
      const option = this.moduleTypeOptions.find(
        (option) => option.moduleTypeName === moduleTypeName
      );

      this.getMicroTypes(option ? option.moduleTypeCode : "");
    }
  }

  validateSBLData() {
    const {
      releaseType,
      microTypeName,
      moduleTypeCode,
      supplierCode,
      leadMyProgram,
      currentPartNumber,
    } = this.sblData;

    let errorMessages = [];

    // Check required fields
    if (!releaseType) {
      errorMessages.push("* Select Release Type.");
    }
    if (!moduleTypeCode) {
      errorMessages.push("* Select Module Type.");
    }

    // Additional checks for "new_sbl"
    if (releaseType === "new_sbl") {
      if (!microTypeName) {
        errorMessages.push("* Select Main Micro Type.");
      }
      if (!supplierCode) {
        errorMessages.push("* Select Supplier Code.");
      }

      // Validate Lead MY/Program using the new function
      const leadMyProgramError = ReleaseUtils.validateFieldNoHtmTags(
        leadMyProgram,
        "Lead MY/Program",
        1
      );
      if (leadMyProgramError) {
        errorMessages.push(leadMyProgramError);
      }
    }

    // Additional check for "replace_sbl"
    if (releaseType === "replace_sbl") {
      if (!currentPartNumber) {
        errorMessages.push("* Enter Current Part Number.");
      } else if (!ReleaseUtils.isPartNumber(currentPartNumber)) {
        errorMessages.push("* Current Part Number Required.");
      } else {
        const basePartNumberError = ReleaseUtils.validateSblBasePartNumber(
          moduleTypeCode,
          currentPartNumber
        );
        if (basePartNumberError) {
          errorMessages.push(basePartNumberError);
        }
      }
    }

    // If there are any error messages, display them using SweetAlert
    if (errorMessages.length > 0) {
      const fullMessage =
        errorMessages.join("<br>") +
        "<br><br>Please correct the issues listed above and try again.";
      ReleaseUtils.showErrorSweetAlert("Error", fullMessage);
      return false;
    }

    return true;
  }

  addNewSBL(sblData: AddSblPostModel) {
    this.releaseService.addSbl(sblData).subscribe({
      next: (response: any) => {
        const successMessage = response;
        Swal.fire({
          icon: "success",
          title: "Success",
          text: successMessage,
          confirmButtonColor: "#00467f",
        }).then(() => {
          this.router.navigate(["/"]);
        });
      },
      error: (error: any) => {
        // Parse the error string
        let errorResponse: ErrorResponse;
        try {
          errorResponse = JSON.parse(error.error);
        } catch (e) {
          errorResponse = {
            status: "error",
            message: "An unexpected error occurred.",
          };
        }

        const errorMessage =
          errorResponse.message || "An unexpected error occurred.";
        ReleaseUtils.showErrorSweetAlert("Error", `${errorMessage}`);
      },
    });
  }

  replaceNewSBL(sblData: ReplaceSblPutModel) {
    this.releaseService.replaceSbl(sblData).subscribe({
      next: (response: any) => {
        const successMessage = response;
        Swal.fire({
          icon: "success",
          title: "Success",
          text: successMessage,
          confirmButtonColor: "#00467f",
        }).then(() => {
          this.router.navigate(["/"]);
        });
      },
      error: (error: any) => {
        // Parse the error string
        let errorResponse: ErrorResponse;
        try {
          errorResponse = JSON.parse(error.error);
        } catch (e) {
          errorResponse = {
            status: "error",
            message: "An unexpected error occurred.",
          };
        }

        const errorMessage =
          errorResponse.message || "An unexpected error occurred.";
        ReleaseUtils.showErrorSweetAlert("Error", `${errorMessage}`);
      },
    });
  }

  addSBL() {
    if (this.validateSBLData()) {
      const {
        supplierCode,
        releaseType,
        moduleTypeCode,
        microTypeCode,
        description,
        leadMyProgram,
        currentPartNumber,
      } = this.sblData;
      if (releaseType === "new_sbl") {
        const dataToSend: AddSblPostModel = {
          supplierCode,
          moduleTypeCode,
          microTypeCode,
          description,
          leadMyProgram,
          userId: "DSADASH1",
        };
        this.addNewSBL(dataToSend);
      }
      if (releaseType === "replace_sbl") {
        const dataToSend: ReplaceSblPutModel = {
          moduleTypeCode,
          description,
          currentPartNumber,
          userId: "DSADASH1",
        };
        this.replaceNewSBL(dataToSend);
      }
    }
  }

  cancelSubmit() {
    this.sblData = new SblModel();
    this.sblData.releaseType === "new_sbl";
    window.scrollTo({ top: 0, behavior: "smooth" });
    this.router.navigate(["/"]);
  }
}
