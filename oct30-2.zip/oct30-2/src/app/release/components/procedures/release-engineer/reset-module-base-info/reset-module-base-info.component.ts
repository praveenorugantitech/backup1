import { Component } from '@angular/core';

@Component({
  selector: 'app-reset-module-base-info',
  templateUrl: './reset-module-base-info.component.html',
  styleUrl: './reset-module-base-info.component.scss'
})
export class ResetModuleBaseInfoComponent {

}
