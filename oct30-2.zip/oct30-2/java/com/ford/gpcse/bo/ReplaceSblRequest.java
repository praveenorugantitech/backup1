package com.ford.gpcse.bo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
public class ReplaceSblRequest {
    private String moduleTypeCode;
    private String currentPartNumber;
    private String description;
    private String userId;
}
