package com.ford.gpcse.bo;

import com.ford.gpcse.dto.LookupPartFirmwareDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
public class GroupedFirmwareResponse {
    private String category;
    private List<LookupPartFirmwareDto> firmwares;
}
