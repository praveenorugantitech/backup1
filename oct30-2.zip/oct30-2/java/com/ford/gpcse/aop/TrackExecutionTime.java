package com.ford.gpcse.aop;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Annotation to indicate that the execution time of a method should
 * be tracked. Methods annotated with @TrackExecutionTime will have
 * their execution duration measured and logged by the
 * ExecutionTimeTrackerAdvice aspect.
 */
@Target(ElementType.METHOD)  // This annotation can be applied to methods.
@Retention(RetentionPolicy.RUNTIME)  // The annotation is available at runtime.
public @interface TrackExecutionTime {
    // No attributes are required for this annotation.
}
