package com.ford.gpcse.external.vsem.service.impl;

import com.ford.gpcse.config.AppConfig;
import com.ford.gpcse.external.vsem.service.AuthService;
import com.ford.gpcse.external.vsem.service.VsemService;
import com.ford.gpcse.model.VsemServiceResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

/**
 * Implementation of the VsemService interface for fetching part filenames.
 * This service uses an authentication service to obtain a token and
 * then makes a request to the Vsem API to retrieve part information.
 */
@Service
@RequiredArgsConstructor
public class VsemServiceImpl implements VsemService {

    private final AuthService authService; // Service to handle authentication and token retrieval
    private final AppConfig appConfig; // Configuration properties for the Vsem API
    private final RestTemplate restTemplate; // RestTemplate for making HTTP requests

    /**
     * Fetches part filenames for a given part number.
     *
     * @param partNumber The part number to retrieve filenames for
     * @return VsemServiceResponse containing the part filenames
     * @throws RuntimeException if there is an error during the API request
     */
    @Override
    public VsemServiceResponse fetchPartFilenames(String partNumber) {
        // Get access token using the AuthService
        String accessToken = authService.fetchToken().getAccessToken();

        // Prepare headers for the API request
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + accessToken); // Set the Authorization header with the Bearer token
        headers.set("partNumber", partNumber); // Include the part number in the headers

        // Create HttpEntity with the headers
        HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

        try {
            // Send GET request to the Vsem API using RestTemplate
            ResponseEntity<VsemServiceResponse> response = restTemplate.exchange(
                    appConfig.getVsemurl(), // URL from configuration
                    HttpMethod.GET, // HTTP method
                    requestEntity, // Request entity with headers
                    VsemServiceResponse.class // Response type
            );

            // Return the body of the response
            return response.getBody();
        } catch (RestClientException e) {
            // Handle exceptions related to the REST client and throw a runtime exception
            throw new RuntimeException("Error fetching part filenames", e);
        }
    }
}
