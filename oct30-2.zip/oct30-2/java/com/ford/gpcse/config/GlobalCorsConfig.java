package com.ford.gpcse.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Configuration class to set up global CORS (Cross-Origin Resource Sharing) settings
 * for the application. This allows for the specified origins, methods, and headers
 * to access the application's endpoints.
 */
@Configuration
public class GlobalCorsConfig {

    /**
     * Defines a WebMvcConfigurer bean to customize CORS mappings.
     *
     * @return a WebMvcConfigurer that configures CORS settings.
     */
    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                // Apply CORS settings to all endpoints
                registry.addMapping("/**")  // Apply to all endpoints
                        .allowedOrigins("*") // Allow all origins
                        .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS") // Allow specified HTTP methods
                        .allowedHeaders("*") // Allow all headers
                        .allowCredentials(false); // Disable credentials support
            }
        };
    }
}
