package com.ford.gpcse.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCM001_USER")
public class User {
    @Id
    @Column(name = "PCM001_USER_CDSID_C", length = 8, nullable = false)
    private String userCdsidC;

    @OneToMany(mappedBy="user")
    private List<UserRole> userRoles;

    @Column(name = "PCM001_USER_N", length = 60)
    private String userN;

    @Column(name = "PCM001_EMAIL_ADDR_X", length = 100, nullable = false)
    private String emailAddrX;

    @Column(name = "PCM001_ARCH_F", length = 1, nullable = false)
    private String archF;

    @Column(name = "PCM001_PASSWORD_X", length = 40)
    private String passwordX;

    @Column(name = "PCM001_COMP_N", length = 50)
    private String compN;

    @Column(name = "PCM001_CMT_X", length = 100)
    private String cmtX;

    @Column(name = "PCM001_CREATE_USER_C", length = 8, nullable = false)
    private String createUserC;

    @NotNull
    @CreationTimestamp
    @Column(name = "PCM001_CREATE_S", nullable = false, updatable = false)
    private LocalDateTime createS;

    @Column(name = "PCM001_LAST_UPDT_USER_C", length = 8, nullable = false)
    private String lastUpdtUserC;

    @NotNull
    @UpdateTimestamp
    @Column(name = "PCM001_LAST_UPDT_S", nullable = false)
    private LocalDateTime lastUpdtS;

    @Column(name = "PCM001_PASSWORD_EXP_Y", nullable = false)
    private LocalDateTime passwordExpY;

    @Column(name = "PCM001_USER_DOMAIN_C", length = 10)
    private String userDomainC;

    @Column(name = "PCM001_USER_SECUR_D", length = 60)
    private String userSecurD;

    @Column(name = "PCM001_FRST_N", length = 25)
    private String frstN;

    @Column(name = "PCM001_LST_N", length = 25)
    private String lstN;
}
