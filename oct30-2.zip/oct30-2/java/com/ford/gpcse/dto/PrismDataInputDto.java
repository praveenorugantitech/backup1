package com.ford.gpcse.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PrismDataInputDto {
    private String partR;
    private String calibR;
    private String wersNtcR;
    private String stratRelC;
    private String stratCalibPartR;
    private String chipD;
    private String hardwarePartR;
    private String catchWordC;
    private LocalDate reldY;
    private String microTypeX;
    private String relUsgC;
    private String vehicleLine;
    private String supplier;
    private String engine;
    private String relTypC;
}
