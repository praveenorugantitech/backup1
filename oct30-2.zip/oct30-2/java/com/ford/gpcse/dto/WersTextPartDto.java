package com.ford.gpcse.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class WersTextPartDto {

    private String partR;
    private String relTypeC;
    private String backwardCompatC;
    private String hardwarePartR;
    private String releaseUsageC;
    private String programs; // Comma-separated string of program keys
}
