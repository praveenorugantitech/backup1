package com.ford.gpcse.repository;

import com.ford.gpcse.entity.ReleaseRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository interface for accessing ReleaseRequest entities.
 * Extends JpaRepository for standard CRUD operations and JpaSpecificationExecutor for dynamic queries.
 */
@Repository
public interface ReleaseRequestRepository extends JpaRepository<ReleaseRequest, Long>, JpaSpecificationExecutor<ReleaseRequest> {

    /**
     * Retrieves all ReleaseRequest entities ordered by their release request key in descending order.
     *
     * @return a list of ReleaseRequest entities ordered by relReqK
     */
    List<ReleaseRequest> findAllByOrderByRelReqKDesc();

    /**
     * Retrieves Release Request Details based on id.
     *
     * @return a Release Request
     */
    ReleaseRequest findByRelReqK(Long id);

}
