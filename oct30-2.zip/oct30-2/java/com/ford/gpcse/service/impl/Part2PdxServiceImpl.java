package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.Part2PdxRequest;
import com.ford.gpcse.entity.MicroType;
import com.ford.gpcse.entity.ModuleType;
import com.ford.gpcse.entity.Part;
import com.ford.gpcse.entity.ReleaseType;
import com.ford.gpcse.exception.InvalidPartNumberException;
import com.ford.gpcse.external.vsem.service.VsemService;
import com.ford.gpcse.model.VsemServiceResponse;
import com.ford.gpcse.repository.FirmwareItemRepository;
import com.ford.gpcse.repository.PartRepository;
import com.ford.gpcse.service.Part2PdxService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class Part2PdxServiceImpl implements Part2PdxService {

    private final VsemService vsemService;
    private final PartRepository partRepository;
    private final FirmwareItemRepository firmwareItemRepository;

    @Override
    @Transactional
    public String addNewPart2OrPdx(Part2PdxRequest part2PdxRequest) {

        if (part2PdxRequest.getReleaseType().equals("PII")) {

            VsemServiceResponse vsemServiceResponse = vsemService.fetchPartFilenames(part2PdxRequest.getPartNumber());
            if (vsemServiceResponse == null || vsemServiceResponse.getPartfilenames() == null) {
                return "Unable to find part in VSEM";
            }

            if (vsemServiceResponse.getStatus() != 200 || !vsemServiceResponse.getMessage().isEmpty()) {
                return vsemServiceResponse.getMessage();
            }

            StringBuilder retVal = new StringBuilder();

            if (vsemServiceResponse.getPartfilenames().contains(part2PdxRequest.getPartNumber() + ".mdx")) {
                retVal.append("Missing mdx file\n");
            }

            if (!vsemServiceResponse.getPartfilenames().contains(part2PdxRequest.getPartNumber() + ".mdx.log")) {
                retVal.append("Missing mdx.log file\n");
            }

            if (!vsemServiceResponse.getPartfilenames().contains(part2PdxRequest.getPartNumber() + ".docx")
                    && !vsemServiceResponse.getPartfilenames().contains(part2PdxRequest.getPartNumber() + ".doc")) {
                retVal.append("Missing doc or docx file\n");
            }

            // Check part 2 status
            List<String> approvedPart2Status = Arrays.asList("Definition Approved", "Vehicle Configuration Complete");

            if (!approvedPart2Status.contains(vsemServiceResponse.getPartstatus())) {
                retVal.append("Part 2 is not approved. Part 2 status must be approved.\n");
            }

            if (!retVal.isEmpty()) {
                return retVal.toString();
            }


            return "VSEM validation failed.  Your part has not been added.  Please fix VSEM issues and try again.";


        }

        int count = partRepository.countByPartNumber(part2PdxRequest.getPartNumber());

        if (count > 0) {
            throw new InvalidPartNumberException(part2PdxRequest.getPartNumber());
        }

        Part part = Part.builder().partR(part2PdxRequest.getPartNumber())
                .prodnF("Y").archF("N").reldF("Y").createUserC(part2PdxRequest.getCreateUser())
                .lastUpdtUserC(part2PdxRequest.getLastUpdateUser())
                .moduleType(ModuleType.builder().moduleTypC(part2PdxRequest.getModuleTypeCode()).build())
                .releaseType(ReleaseType.builder().relTypC(part2PdxRequest.getReleaseType()).build())
                .microType(MicroType.builder().microTypC(part2PdxRequest.getMicroTypeCode()).build())
                .partNumX(part2PdxRequest.getDescription())
                .engineerCdsidC(part2PdxRequest.getCreateUser())
                .reldY(LocalDate.now())
                .swDlSpecR(part2PdxRequest.getSwdlVersion())
                .genGlblSpecR(part2PdxRequest.getGgdsVersion())
                .build();

        partRepository.save(part);

        String fwType = "PII";

        if (part2PdxRequest.getReleaseType().equals("PDX")) {
            fwType = "PDX ";
        }

        firmwareItemRepository.addFirmwareItemToDropdown("%" + fwType + "%", part2PdxRequest.getModuleTypeCode(), part2PdxRequest.getPartNumber(), part2PdxRequest.getCreateUser());
        return part2PdxRequest.getPartNumber() + " has been added to the firmware drop down list.";
    }
}
