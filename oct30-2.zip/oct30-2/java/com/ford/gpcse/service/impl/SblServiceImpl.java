package com.ford.gpcse.service.impl;

import com.ford.gpcse.aop.LoggingAspect;
import com.ford.gpcse.bo.CreateSblRequest;
import com.ford.gpcse.bo.ReplaceSblRequest;
import com.ford.gpcse.dto.ReplaceSblPartDetailsDto;
import com.ford.gpcse.entity.*;
import com.ford.gpcse.exception.ResourceAlreadyExistException;
import com.ford.gpcse.exception.ResourceNotFoundException;
import com.ford.gpcse.exception.UnableToInsertException;
import com.ford.gpcse.exception.UnableToUpdateException;
import com.ford.gpcse.external.email.service.EmailService;
import com.ford.gpcse.model.Email;
import com.ford.gpcse.repository.*;
import com.ford.gpcse.service.ReleaseProcessService;
import com.ford.gpcse.service.SblService;
import com.ford.gpcse.util.DateFormatterUtility;
import com.ford.gpcse.util.PartNumberUtility;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class SblServiceImpl implements SblService {

    private final PartRepository partRepository;
    private final EmailService emailService;
    private final PartSignoffRepository partSignoffRepository;
    private final SupplierRepository supplierRepository;
    private final MicroTypeRepository microTypeRepository;
    private final ModuleTypeRepository moduleTypeRepository;
    private final ReleaseTypeRepository releaseTypeRepository;
    private final RelUsgRepository relUsgRepository;
    private final ReleaseProcessService releaseProcessService;

    @Override
    @Transactional
    public void createSbl(CreateSblRequest createSblRequest) {
        RelUsg releaseUsage = RelUsg.builder().relUsgC("PROD").build();
        ReleaseType releaseType = ReleaseType.builder().relTypC("SBL").build();
        ModuleType moduleType = ModuleType.builder().moduleTypC(createSblRequest.getModuleTypeCode()).build();
        MicroType microType = MicroType.builder().microTypC(createSblRequest.getMicroTypeCode()).build();
        Supplier supplier = Supplier.builder().suplC(createSblRequest.getSupplierCode()).build();
        Part part = Part.builder()
                .partR("-" + createSblRequest.getUserId() + DateFormatterUtility.dateTimeStringNewPart(LocalDateTime.now()) + "-SBL")
                .createUserC(createSblRequest.getUserId() != null ? createSblRequest.getUserId() : "Ram")
                .lastUpdtUserC(createSblRequest.getUserId() != null ? createSblRequest.getUserId() : "Ram")
                .releaseUsage(releaseUsage)
                .releaseType(releaseType)
                .moduleType(moduleType)
                .microType(microType)
                .cmtX(createSblRequest.getDescription())
                .supplier(supplier)
                .concernY(LocalDate.now())
                .concernC("SBL" + DateFormatterUtility.dateTimeStringInYYMMDD(LocalDate.now()))
                .statC("NewPnRequest")
                .engineerCdsidC(createSblRequest.getUserId())
                .procCmtX(createSblRequest.getLeadMyProgram())
                .partNumX(createSblRequest.getLeadMyProgram())
                .build();
        Part savedPart = partRepository.save(part);

        if (savedPart.getPartR() == null) {
            throw new UnableToInsertException("Unable to insert '" + part.getPartR() + "'. Internal Error 1699.");
        }
        log.info("Sbl created successfully {}", savedPart.getPartR());

        // setup signoff process
        releaseProcessService.setupSignOffProcess(savedPart.getPartR(), "SBL", "PROD", createSblRequest.getUserId(), createSblRequest.getUserId());

        sendNewPartEmail(savedPart, "Create");
    }

    @Override
    @Transactional
    public void replaceSbl(ReplaceSblRequest replaceSblRequest) {
        if (replaceSblRequest.getCurrentPartNumber() == null) {
            throw new IllegalArgumentException("Current Part Number must not be null");
        }

        String newPartNumber = PartNumberUtility.incrementPartNumber(replaceSblRequest.getCurrentPartNumber());

        // Verify current and new part number in the database
        List<ReplaceSblPartDetailsDto> results = partRepository.fetchPartDetails(replaceSblRequest.getCurrentPartNumber(), newPartNumber);
        if (results.isEmpty()) {
            throw new ResourceNotFoundException("No Records was found.");
        }
        ReplaceSblPartDetailsDto partDetails = results.get(0);
        if (partDetails.getNewPartCheck() > 0) {
            throw new ResourceAlreadyExistException("Part Number " + newPartNumber + " already exists in the database.");
        }

        RelUsg releaseUsage = relUsgRepository.findByRelUsgC("PROD");
        ReleaseType releaseType = releaseTypeRepository.findByRelTypC("SBL");
        ModuleType moduleType = moduleTypeRepository.findByModuleTypC(partDetails.getModuleTypeCode());
        MicroType microType = microTypeRepository.findByMicroTypC(partDetails.getMicroTypeCode());
        Supplier supplier = supplierRepository.findBySuplC(partDetails.getSupplierCode());


        Part part = Part.builder()
                .partR(newPartNumber)
                .prodnF("Y")
                .archF("N")
                .reldF("N")
                .createS(LocalDateTime.now())
                .createUserC(Optional.ofNullable(replaceSblRequest.getUserId()).orElse("Ram"))
                .lastUpdtUserC(Optional.ofNullable(replaceSblRequest.getUserId()).orElse("Ram"))
                .lastUpdtS(LocalDateTime.now())
                .moduleType(moduleType)
                .releaseType(releaseType)
                .microType(microType)
                .cmtX(replaceSblRequest.getDescription())
                .engineerCdsidC(replaceSblRequest.getUserId())
                .replacedPartR(replaceSblRequest.getCurrentPartNumber())
                .statC("NewPnRequest")
                .concernC("SBL" + DateFormatterUtility.dateTimeStringInYYMMDD(LocalDate.now()))
                .concernY(LocalDate.now())
                .releaseUsage(releaseUsage)
                .supplier(supplier)
                .build();
        Part savedPart = partRepository.save(part);

        if (savedPart.getPartR() == null) {
            throw new UnableToInsertException("Unable to insert " + newPartNumber + ". Internal Error 1699.");
        }
        log.info("Sbl replaced successfully {}", savedPart.getPartR());

        // setup signoff process
        releaseProcessService.setupSignOffProcess(savedPart.getPartR(), "SBL", "PROD", replaceSblRequest.getUserId(), replaceSblRequest.getUserId());


        // update hardlock status
        int hardLockUpdate = partRepository.updatePartStatusAndCalib("SBLXX" + DateFormatterUtility.dateTimeStringNotice(LocalDateTime.now()), part.getPartR());

        if (hardLockUpdate > 0) {
            log.info("Hard Lock Status update success for Part {}", part.getPartR());
            // update signoff type as DCUUL

            int partSignOffUpdate = partSignoffRepository.updateUserCdsidCForSignoffs("DCUUL", part.getPartR());

            if (partSignOffUpdate == 0) {
                throw new UnableToUpdateException("Unable to update signoff type for part" + part.getPartR());
            }


        } else {
            throw new UnableToUpdateException("Unable to update HardLock status for part" + part.getPartR());
        }

        sendNewPartEmail(savedPart, "Replace");
    }

    @LoggingAspect
    private void sendNewPartEmail(Part savedPart, String type) {

        String description = type.equals("Create") ? " has requested parts for " : " has created parts for ";
        String emailBody = "<html><body><p>" + savedPart.getCreateUserC() +
                description +
                savedPart.getConcernC() + ".</p>" +
                "<pre>" + savedPart.getCmtX() + "</pre></body></html>";

        Email email = Email.builder()
                .from("")// pcserel@ford.com
                .to(List.of())
                .subject(savedPart.getCreateUserC() + description + savedPart.getConcernC() + " .")
                .body(emailBody)
                .build();
        emailService.sendMail(email);
    }
}