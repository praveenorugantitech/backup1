package com.ford.gpcse.controller;

import com.ford.gpcse.aop.LoggingAspect;
import com.ford.gpcse.aop.TrackExecutionTime;
import com.ford.gpcse.bo.*;
import com.ford.gpcse.dto.ProgramDescriptionDto;
import com.ford.gpcse.service.LookupDataService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controller for fetching various lookup data.
 * This class provides endpoints for retrieving active suppliers,
 * module types, micro types, release types, and other related information.
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1_0/lookup")
@Tag(description = "Fetch All Active Micro Names, Fetch Released Micro Types Based on Module Type, " +
        "Fetch All Active Module Names, Fetch All Active Module Types, Fetch Distinct Programs, " +
        "Fetch All Active Suppliers, Fetch All Release Requests, Fetch All Release Status Details, " +
        "Fetch Module Base Information Based on user id, Fetch Parts By Firmware, " +
        "Fetch Prism Input Data Based on Part Number, Fetch Firmware Details Based on Release Type, " +
        "Fetch Active Release Types and Fetch All Programs Which Has Part Number.", name = "Lookup Data")
public class LookupDataController {

    private final LookupDataService lookupDataService; // Service for handling lookup data operations

    /**
     * Endpoint for fetching all active suppliers.
     *
     * @return a list of active suppliers
     */
    @GetMapping("/suppliers")
    @Operation(description = "Fetch All Active Suppliers", summary = "Fetch All Active Suppliers")
    @LoggingAspect // Enable logging for this method
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<SupplierView> fetchActiveSuppliers() {
        return lookupDataService.fetchActiveSuppliers();
    }

    /**
     * Endpoint for fetching all active module types.
     *
     * @return a list of active module types
     */
    @GetMapping("/module-types")
    @Operation(description = "Fetch All Active Module Types", summary = "Fetch All Active Module Types")
    @LoggingAspect // Enable logging for this method
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<ModuleTypeView> fetchActiveModuleTypes() {
        return lookupDataService.fetchActiveModuleTypes();
    }

    /**
     * Endpoint for fetching all active release usages.
     *
     * @return a list of active release usages
     */
    @GetMapping("/release-usages")
    @Operation(description = "Fetch All Active Release Usages", summary = "Fetch All Active Release Usages")
    @LoggingAspect // Enable logging for this method
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<ReleaseUsageView> fetchActiveReleaseUsages() {
        return lookupDataService.fetchActiveReleaseUsages();
    }

    /**
     * Endpoint for fetching released micro types based on a module type.
     *
     * @param moduleTypeCode the module type code to filter micro types
     * @return a list of released micro types for the specified module type
     */
    @GetMapping("/micro-types")
    @Operation(description = "Fetch Released Micro Types Based on Module Type", summary = "Fetch Released Micro Types Based on Module Type")
    @LoggingAspect // Enable logging for this method
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<MicroTypeView> fetchReleasedMicroTypesByModuleType(@RequestParam String moduleTypeCode) {
        return lookupDataService.fetchReleasedMicroTypesByModuleType(moduleTypeCode);
    }

    /**
     * Endpoint for fetching all release types based on a module type.
     *
     * @param moduleTypeCode the module type code to filter release types
     * @return a list of release types for the specified module type
     */
    @GetMapping("/release-types/module-type/{moduleTypeCode}")
    @Operation(description = "Fetch All Release Types Based on Module Type", summary = "Fetch All Release Types Based on Module Type")
    @LoggingAspect // Enable logging for this method
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<String> fetchReleaseTypesByModuleType(@PathVariable String moduleTypeCode) {
        return lookupDataService.fetchReleaseTypesByModuleType(moduleTypeCode);
    }

    /**
     * Endpoint for fetching all active micro names.
     *
     * @return a list of active micro names
     */
    @GetMapping("/micro-names")
    @Operation(description = "Fetch All Active Micro Names", summary = "Fetch All Active Micro Names")
    @LoggingAspect // Enable logging for this method
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<String> fetchActiveMicroNames() {
        return lookupDataService.fetchActiveMicroNames();
    }

    /**
     * Endpoint for fetching all active module names.
     *
     * @return a list of active module names
     */
    @GetMapping("/module-names")
    @Operation(description = "Fetch All Active Module Names", summary = "Fetch All Active Module Names")
    @LoggingAspect // Enable logging for this method
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<String> fetchActiveModuleNames() {
        return lookupDataService.fetchActiveModuleNames();
    }

    /**
     * Endpoint for fetching distinct programs.
     *
     * @return a list of distinct programs
     */
    @GetMapping("/programs")
    @Operation(description = "Fetch Distinct Programs", summary = "Fetch Distinct Programs")
    @LoggingAspect // Enable logging for this method
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<ProgramDescriptionDto> fetchDistinctPrograms() {
        return lookupDataService.fetchDistinctPrograms();
    }

    /**
     * Endpoint for fetching all programs which have a part number.
     *
     * @return a list of programs with part numbers
     */
    @GetMapping("/programs/with-part-number")
    @Operation(description = "Fetch All Programs Which Has Part Number", summary = "Fetch All Programs Which Has Part Number")
    @LoggingAspect // Enable logging for this method
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<String> fetchAllProgramsWhichHasPartNumber() {
        return lookupDataService.fetchAllProgramsWhichHasPartNumber();
    }

    /**
     * Endpoint for fetching the release request details based on id
     *
     * @return ReleaseRequest
     */

    @LoggingAspect // Enable logging for this method
    @TrackExecutionTime // Track execution time for this method
    @GetMapping("/release-request/{id}")
    @Operation(description = "Fetch Release Request By Id", summary = "Fetch Release Request By Id")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public ReleaseRequestDetail fetchReleaseRequestDetailsById(@PathVariable("id") Long id) {
        return lookupDataService.fetchReleaseRequestDetailsById(id);
    }

    /**
     * Endpoint for fetching all release requests.
     *
     * @return a list of release requests
     */
    @LoggingAspect // Enable logging for this method
    @TrackExecutionTime // Track execution time for this method
    @GetMapping("/release-request")
    @Operation(description = "Fetch All Release Requests", summary = "Fetch All Release Requests")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<ReleaseRequestOutput> fetchAllReleaseRequests() {
        return lookupDataService.fetchAllReleaseRequests();
    }

    /**
     * Endpoint for fetching all release status details.
     *
     * @return a list of release status details
     */
    @LoggingAspect // Enable logging for this method
    @TrackExecutionTime // Track execution time for this method
    @GetMapping("/release-status")
    @Operation(description = "Fetch All Release Status Details", summary = "Fetch All Release Status Details")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<ReleaseStatus> fetchReleaseStatusDetails() {
        return lookupDataService.fetchReleaseStatusDetails();
    }

    /**
     * Endpoint for fetching all active release types.
     *
     * @return a list of active release types
     */
    @LoggingAspect // Enable logging for this method
    @TrackExecutionTime // Track execution time for this method
    @GetMapping("/release-types")
    @Operation(description = "Fetch Active Release Types", summary = "Fetch Active Release Types")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<ReleaseTypeView> fetchActiveReleaseTypes() {
        return lookupDataService.fetchActiveReleaseTypes();
    }

    /**
     * Endpoint for fetching module base information based on user ID.
     *
     * @param userId the user ID to filter module base information
     * @return a list of module base information for the specified user
     */
    @LoggingAspect // Enable logging for this method
    @TrackExecutionTime // Track execution time for this method
    @GetMapping("/module-base-info/user-id/{userId}")
    @Operation(description = "Fetch Module Base Information Based on User Id", summary = "Fetch Module Base Information Based on User Id")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<ModuleBaseInformation> fetchModuleBaseInformation(@PathVariable("userId") String userId) {
        return lookupDataService.fetchModuleBaseInformation(userId);
    }

    /**
     * Endpoint for fetching parts by firmware based on a request object.
     *
     * @param replacePblSearchRequest the request object containing search parameters
     * @return a response entity containing a list of parts by firmware
     */
    @TrackExecutionTime // Track execution time for this method
    @LoggingAspect // Enable logging for this method
    @PostMapping(value = "/parts-by-firmware")
    @Operation(
            summary = "Fetch Parts by Firmware",
            description = "Fetch parts by firmware based on the current and replace PBL"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public ResponseEntity<List<PartFirmwareResponse>> findPartsByFirmware(@RequestBody ReplacePblSearchRequest replacePblSearchRequest) {
        return ResponseEntity.ok(lookupDataService.findPartsByFirmware(replacePblSearchRequest));
    }

    /**
     * Endpoint for fetching prism input data based on part number.
     *
     * @param partNumber the part number to filter prism input data
     * @return a response entity containing prism input data for the specified part number
     */
    @TrackExecutionTime // Track execution time for this method
    @LoggingAspect // Enable logging for this method
    @GetMapping(value = "/data-prism-input/part-number/{partNumber}")
    @Operation(
            summary = "Fetch Prism Input Data Based on Part Number",
            description = "Fetch Prism Input Data Based on Part Number"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public ResponseEntity<PrismDataInputResponse> fetchPrismInputDataBasedOnPartNumber(@PathVariable("partNumber") String partNumber) {
        return ResponseEntity.ok(lookupDataService.fetchPrismInputDataBasedOnPartNumber(partNumber));
    }

    /**
     * Endpoint for fetching firmware details based on release type.
     *
     * @param releaseType the release type to filter firmware details
     * @return a response entity containing firmware details for the specified release type
     */
    @TrackExecutionTime // Track execution time for this method
    @LoggingAspect // Enable logging for this method
    @GetMapping(value = "/firmware/release-type/{releaseType}")
    @Operation(
            summary = "Fetch Firmware Details Based on Release Type",
            description = "Fetch Firmware Details Based on Release Type"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public ResponseEntity<List<FirmwareDetailsResponse>> fetchFirmwareDetailsBasedOnReleaseType(@PathVariable("releaseType") String releaseType) {
        return ResponseEntity.ok(lookupDataService.fetchFirmwareDetailsBasedOnReleaseType(releaseType));
    }
}
