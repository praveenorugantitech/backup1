package com.ford.gpcse.controller;

import com.ford.gpcse.aop.LoggingAspect;
import com.ford.gpcse.aop.TrackExecutionTime;
import com.ford.gpcse.bo.ExportFirwareXmlRequest;
import com.ford.gpcse.bo.ReleaseRequestSearchInput;
import com.ford.gpcse.service.ExportToExcelService;
import com.ford.gpcse.service.ExportToXmlService;
import com.ford.gpcse.util.DateFormatterUtility;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Controller for exporting data, including parts and firmware XML.
 * This class provides endpoints to export parts based on part numbers
 * and to fetch firmware XML files, with logging and execution time tracking.
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1_0/export")
@Tag(description = "Fetch Firmware Xml and Export Parts Based on Part Numbers to Excel", name = "Export Data")
public class ExportDataController {

    private final ExportToXmlService exportToXmlService; // Service for exporting firmware XML
    private final ExportToExcelService exportToExcelService; // Service for exporting parts to Excel

    /**
     * Endpoint for exporting parts based on part numbers.
     *
     * @param partNumbers the list of part numbers to be exported
     * @return a ResponseEntity containing the Excel report as a resource
     */
    @TrackExecutionTime  // Track the execution time of this method
    @LoggingAspect  // Enable logging for this method
    @PostMapping(value = "/parts")
    @Operation(
            summary = "Export Parts Based on Part Numbers to Excel",
            description = "Export Parts Based on Part Numbers to Excel"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully Exported Parts to Excel")
    })
    public ResponseEntity<Resource> exportPartsBasedOnPartNumbersInExcel(@RequestBody List<String> partNumbers) {
        try {
            // Generate the Excel report stream for the given part numbers
            InputStream partsExcelReportStream = exportToExcelService.exportPartsBasedOnPartNumbers(partNumbers);
            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=FirmwareExport.xlsx");
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);

            return ResponseEntity.ok().headers(headers).body(new InputStreamResource(partsExcelReportStream));
        } catch (IOException e) {
            // Handle any IO exceptions that occur during export
            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new InputStreamResource(new ByteArrayInputStream(("Error occurred: " + e.getMessage()).getBytes())));
        }
    }

    /**
     * Endpoint for fetching firmware XML based on the provided request.
     *
     * @param exportFirwareXmlRequest the request object containing parameters for fetching firmware XML
     * @return a ResponseEntity containing the firmware XML as a resource
     */
    @TrackExecutionTime  // Track the execution time of this method
    @LoggingAspect  // Enable logging for this method
    @PostMapping(value = "/firmware-xml")
    @Operation(
            summary = "Fetch Firmware xml",
            description = "Fetch Firmware xml"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully Retrieved the Firmware Xml")
    })
    public ResponseEntity<Resource> fetchFirmareXml(@RequestBody ExportFirwareXmlRequest exportFirwareXmlRequest) {
        // Fetch the firmware XML resource
        Resource resource = exportToXmlService.fetchFirmareXml(exportFirwareXmlRequest);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=" +
                                (exportFirwareXmlRequest.getFileName() != null && !exportFirwareXmlRequest.getFileName().isEmpty()
                                        ? exportFirwareXmlRequest.getFileName()
                                        : DateFormatterUtility.dateTimeStringFormatFilename(LocalDateTime.now()) + ".xml")
                )
                .header(HttpHeaders.CONTENT_TYPE, "application/xml")
                .body(resource);
    }

    /**
     * Endpoint for exporting based on release request
     *
     * @param releaseRequestSearchInput Release Request Search Input
     * @return a ResponseEntity containing the Excel report as a resource
     */
    @TrackExecutionTime  // Track the execution time of this method
    @LoggingAspect  // Enable logging for this method
    @PostMapping(value = "/release-request")
    @Operation(
            summary = "Export Release Request Details To Excel",
            description = "Export Release Request Details To Excel"
    )
    public ResponseEntity<Resource> exportReleaseRequestDetailsInExcel(@RequestBody ReleaseRequestSearchInput releaseRequestSearchInput) {
        try {
            // Generate the Excel report stream for the given part numbers
            InputStream partsExcelReportStream = exportToExcelService.exportReleaseRequestDetails(releaseRequestSearchInput);
            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=ReleaseRequestSearchResult" + LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd")) + ".xlsx");
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);

            return ResponseEntity.ok().headers(headers).body(new InputStreamResource(partsExcelReportStream));
        } catch (IOException e) {
            // Handle any IO exceptions that occur during export
            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new InputStreamResource(new ByteArrayInputStream(("Error occurred: " + e.getMessage()).getBytes())));
        }
    }
}
