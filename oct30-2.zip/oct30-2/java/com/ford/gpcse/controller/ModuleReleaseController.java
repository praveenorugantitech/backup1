package com.ford.gpcse.controller;

import com.ford.gpcse.aop.LoggingAspect;
import com.ford.gpcse.aop.TrackExecutionTime;
import com.ford.gpcse.bo.*;
import com.ford.gpcse.service.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Controller for managing module release operations.
 * This class provides endpoints for creating and replacing SBLs, PBLs, main micro types,
 * and handling Part 2 or PDX requests.
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1_0/module-release")
@Tag(description = "Request New Main Micro Type, Add New Part 2 or PDX, Add New PBL, Add New SBL.", name = "Module Release Operations")
public class ModuleReleaseController {

    private final SblService sblService;
    private final PblService pblService;
    private final NewMainMicroTypeService newMainMicroTypeService;
    private final Part2PdxService part2PdxService;
    private final ReleaseRequestService releaseRequestService;
    /**
     * Endpoint to add a new SBL.
     *
     * @param createSblRequest the request object containing details of the SBL to create
     * @return a response entity indicating the status of the creation
     */
    @TrackExecutionTime // Track execution time for this method
    @LoggingAspect // Enable logging for this method
    @PostMapping("/sbl")
    @Operation(
            summary = "Add New SBL Section - Add New SBL",
            description = "Endpoint to add a new SBL under the Add New SBL section."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully created the resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found"),
            @ApiResponse(responseCode = "400", description = "Invalid request")
    })
    public ResponseEntity<String> createSbl(@RequestBody CreateSblRequest createSblRequest) {
        sblService.createSbl(createSblRequest); // Call the service to create the SBL
        return ResponseEntity.status(HttpStatus.CREATED).body("Part request has been submitted."); // Return success response
    }

    /**
     * Endpoint to replace an existing SBL.
     *
     * @param replaceSblRequest the request object containing details for the SBL to replace
     * @return a response entity indicating the status of the replacement
     */
    @TrackExecutionTime // Track execution time for this method
    @LoggingAspect // Enable logging for this method
    @PutMapping("/sbl")
    @Operation(
            summary = "Add New SBL Section - Replace Existing SBL",
            description = "Endpoint to replace an existing SBL under the Add New SBL section."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully created the resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found"),
            @ApiResponse(responseCode = "400", description = "Invalid request")
    })
    public ResponseEntity<String> replaceSbl(@RequestBody ReplaceSblRequest replaceSblRequest) {
        sblService.replaceSbl(replaceSblRequest); // Call the service to replace the SBL
        return ResponseEntity.ok().body("Part request has been submitted."); // Return success response
    }

    /**
     * Endpoint to add a new PBL.
     *
     * @param createPblRequest the request object containing details of the PBL to create
     * @return a response entity indicating the status of the creation
     */
    @TrackExecutionTime // Track execution time for this method
    @LoggingAspect // Enable logging for this method
    @PostMapping(value = "/pbl")
    @Operation(
            summary = "Add New PBL Section - Add New PBL",
            description = "Endpoint to add a new PBL under the Add New PBL section."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully created the resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found"),
            @ApiResponse(responseCode = "400", description = "Invalid request")
    })
    public ResponseEntity<String> createPbl(@RequestBody CreatePblRequest createPblRequest) {
        pblService.createPbl(createPblRequest); // Call the service to create the PBL
        return ResponseEntity.status(HttpStatus.CREATED).body(createPblRequest.getNewPbl() + " has been added to the firmware drop down list"); // Return success response
    }

    /**
     * Endpoint to replace an existing PBL.
     *
     * @param replacePblRequest the request object containing details for the PBL to replace
     * @return a response entity indicating the status of the replacement
     */
    @TrackExecutionTime // Track execution time for this method
    @LoggingAspect // Enable logging for this method
    @PutMapping(value = "/pbl")
    @Operation(
            summary = "Add New PBL Section - Replace Existing PBL",
            description = "Endpoint to replace an existing PBL under the Add New PBL section."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully created the resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found"),
            @ApiResponse(responseCode = "400", description = "Invalid request")
    })
    public ResponseEntity<String> replacePbl(@RequestBody ReplacePblRequest replacePblRequest) {
        pblService.replacePbl(replacePblRequest); // Call the service to replace the PBL
        return ResponseEntity.ok(replacePblRequest.getNewPbl() + " has been added to the firmware drop down list"); // Return success response
    }

    /**
     * Endpoint to request a new main micro type.
     *
     * @param newMicroMicroTypeRequest the request object containing details of the main micro type to request
     * @return a response entity indicating the status of the request
     */
    @TrackExecutionTime // Track execution time for this method
    @LoggingAspect // Enable logging for this method
    @PostMapping("/main-micro-type")
    @Operation(
            summary = "Request New Main Micro Type Section - Request New Main Micro Type",
            description = "Endpoint to request a new main micro type under the Request New Main Micro Type section."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully created the resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found"),
            @ApiResponse(responseCode = "400", description = "Invalid request")
    })
    public ResponseEntity<String> addNewMainMicroType(@RequestBody NewMicroMicroTypeRequest newMicroMicroTypeRequest) {
        newMainMicroTypeService.addNewMainMicroType(newMicroMicroTypeRequest); // Call the service to add the new main micro type
        return ResponseEntity.ok(newMicroMicroTypeRequest.getMainMicroTypeName() + " has been sent for review.  You will be emailed when this Main Micro Type is ready to be used in a release."); // Return success response
    }

    /**
     * Endpoint to add a new Part 2 or PDX.
     *
     * @param part2PdxRequest the request object containing details of the Part 2 or PDX to add
     * @return a response entity indicating the status of the addition
     */
    @TrackExecutionTime // Track execution time for this method
    @LoggingAspect // Enable logging for this method
    @PostMapping("/part2-pdx")
    @Operation(
            summary = "Add New Part2 or Pdx Section - Add New Part2 or Pdx",
            description = "Endpoint to add a new Part2 or PDX under the Add New Part2 or PDX section."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully created the resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found"),
            @ApiResponse(responseCode = "400", description = "Invalid request")
    })
    public ResponseEntity<String> addNewPart2OrPdx(@RequestBody Part2PdxRequest part2PdxRequest) {
        String response = part2PdxService.addNewPart2OrPdx(part2PdxRequest); // Call the service to add the Part 2 or PDX
        return ResponseEntity.ok(response); // Return success response
    }
}
