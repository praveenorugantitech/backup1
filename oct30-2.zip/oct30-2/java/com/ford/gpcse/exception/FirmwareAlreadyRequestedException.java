package com.ford.gpcse.exception;

public class FirmwareAlreadyRequestedException extends RuntimeException {
    public FirmwareAlreadyRequestedException(String firmwareItemX) {
        super(firmwareItemX + "  has already been requested.");
    }
}