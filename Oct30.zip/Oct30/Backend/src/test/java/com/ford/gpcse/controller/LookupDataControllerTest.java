package com.ford.gpcse.controller;

import com.ford.gpcse.bo.MicroTypeView;
import com.ford.gpcse.bo.ModuleTypeView;
import com.ford.gpcse.bo.SupplierView;
import com.ford.gpcse.service.LookupDataService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(LookupDataController.class)
class LookupDataControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private LookupDataService lookupDataService;


    @Test
    void testFetchActiveSuppliers() throws Exception {
        List<SupplierView> suppliers = Arrays.asList(new SupplierView("Bosch", "Bosch"), new SupplierView("Delphi", "Delphi"));
        when(lookupDataService.fetchActiveSuppliers()).thenReturn(suppliers);

        mockMvc.perform(get("/api/v1_0/lookup/suppliers"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].supplierName", is("Bosch")))
                .andExpect(jsonPath("$[0].supplierCode", is("Bosch")))
                .andExpect(jsonPath("$[1].supplierName", is("Delphi")))
                .andExpect(jsonPath("$[1].supplierCode", is("Delphi")));
    }

    @Test
    void testFetchActiveModuleTypes() throws Exception {
        List<ModuleTypeView> moduleTypes = Arrays.asList(new ModuleTypeView("BCCMI", "BCCMI"), new ModuleTypeView("AWDCH", "AWDCH"));
        when(lookupDataService.fetchActiveModuleTypes()).thenReturn(moduleTypes);

        mockMvc.perform(get("/api/v1_0/lookup/module-types"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].moduleTypeCode", is("BCCMI")))
                .andExpect(jsonPath("$[0].moduleTypeName", is("BCCMI")))
                .andExpect(jsonPath("$[1].moduleTypeCode", is("AWDCH")))
                .andExpect(jsonPath("$[1].moduleTypeName", is("AWDCH")));
    }

    @Test
    void testFetchReleasedMicroTypesByModuleType() throws Exception {
        List<MicroTypeView> microTypes = Arrays.asList(new MicroTypeView(1L, "SPANISH OAK 1024"), new MicroTypeView(2L, "MPC-563 Green Oak"));
        when(lookupDataService.fetchReleasedMicroTypesByModuleType("BCCMI")).thenReturn(microTypes);

        mockMvc.perform(get("/api/v1_0/lookup/micro-types")
                        .param("moduleTypeCode", "BCCMI"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].microTypeCode", is(1)))
                .andExpect(jsonPath("$[0].microTypeName", is("SPANISH OAK 1024")))
                .andExpect(jsonPath("$[1].microTypeCode", is(2)))
                .andExpect(jsonPath("$[1].microTypeName", is("MPC-563 Green Oak")));
    }

    @Test
    void testFetchActiveMicroNames() throws Exception {
        List<String> microNames = Arrays.asList("MicroName1", "MicroName2");
        when(lookupDataService.fetchActiveMicroNames()).thenReturn(microNames);

        mockMvc.perform(get("/api/v1_0/lookup/micro-names"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0]", is("MicroName1")))
                .andExpect(jsonPath("$[1]", is("MicroName2")));
    }

    @Test
    void testFetchActiveModuleNames() throws Exception {
        List<String> moduleNames = Arrays.asList("ModuleName1", "ModuleName2");
        when(lookupDataService.fetchActiveModuleNames()).thenReturn(moduleNames);

        mockMvc.perform(get("/api/v1_0/lookup/module-names"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0]", is("ModuleName1")))
                .andExpect(jsonPath("$[1]", is("ModuleName2")));
    }
}