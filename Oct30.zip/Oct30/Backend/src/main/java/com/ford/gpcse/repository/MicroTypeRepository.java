package com.ford.gpcse.repository;

import com.ford.gpcse.entity.MicroType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository interface for managing MicroType entities.
 * This interface extends JpaRepository to provide CRUD operations for MicroType entities.
 */
@Repository
public interface MicroTypeRepository extends JpaRepository<MicroType, Long> {

    /**
     * Fetches a list of released MicroType entities filtered by a specific module type.
     *
     * @param moduleTypeCode The module type code to filter by
     * @return A list of MicroType entities that are released and associated with the specified module type
     */
    @Query("SELECT m FROM MicroType m WHERE m.microTypStatC = 'Released' AND m.archF = 'N' " +
            "AND (m.moduleType.moduleTypC = :moduleTypeCode OR m.moduleType.moduleTypC IS NULL) " +
            "ORDER BY m.microTypX")
    List<MicroType> fetchReleasedMicroTypesByModuleType(@Param("moduleTypeCode") String moduleTypeCode);

    /**
     * Counts the number of MicroType entities with a specific name.
     *
     * @param mainMicroTypeName The name of the MicroType to count
     * @return The count of MicroType entities matching the specified name
     */
    @Query("SELECT COUNT(m) FROM MicroType m WHERE m.microTypX = :mainMicroTypeName")
    int countByMicroTypeName(@Param("mainMicroTypeName") String mainMicroTypeName);

    /**
     * Fetches the next available MicroType ID.
     * If no MicroType exists, it returns 10001.
     *
     * @return The next available MicroType ID
     */
    @Query("SELECT COALESCE(MAX(m.microTypC), 10000) + 1 FROM MicroType m")
    Long fetchMicroId();

    /**
     * Finds a MicroType entity by its unique code.
     *
     * @param microTypeCode The unique code of the MicroType to find
     * @return The MicroType entity with the specified code
     */
    MicroType findByMicroTypC(Long microTypeCode);
}
