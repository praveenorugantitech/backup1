package com.ford.gpcse.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCMR08_CATCHWORD")
public class Catchword {
    @Id
    @Column(name = "PCMR08_CATCHWORD_C", nullable = false)
    private String catchwordC;
    @Column(name = "PCMR08_CATCHWORD_TYP_C")
    private String catchwordTypC;

    @Column(name = "PCMR08_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR08_CREATE_S", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR08_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR08_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;
}
