package com.ford.gpcse.service;

public interface ReleaseProcessService {
    void setupSignOffProcess(String partNumber, String releaseType, String releaseUsage, String createUser, String lastUpdateUser);
}
