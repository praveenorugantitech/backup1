package com.ford.gpcse.bo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
public class CreateSblRequest {
    private String supplierCode;
    private String moduleTypeCode;
    private Long microTypeCode;
    private String description;
    private String leadMyProgram;
    private String userId;
}
