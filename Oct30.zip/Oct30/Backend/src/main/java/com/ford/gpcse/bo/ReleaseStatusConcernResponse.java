package com.ford.gpcse.bo;

import com.ford.gpcse.dto.LookupProgramDescriptionDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
public class ReleaseStatusConcernResponse {
    private String assemblyPN;
    private String calibration;
    private String dRCdsId;
    private String hardwarePN;
    private String coreHardwarePN;
    private String mainMicroType;
    private String softwarePN;
    private String mainStrategy;
    private List<LookupProgramDescriptionDto> programDescriptions;
    private String lineage;
    private ReleaseStatusDetails statusDetails;
}
