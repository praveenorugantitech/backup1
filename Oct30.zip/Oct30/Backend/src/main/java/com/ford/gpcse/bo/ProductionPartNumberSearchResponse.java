package com.ford.gpcse.bo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
public class ProductionPartNumberSearchResponse {

    private String partNumber;
    private String catchWord;
    private String calibrationNumber;
    private String softwarePN;
    private String hardwarePN;
    private String mainMicroType;
    private String wersNotice;

}
