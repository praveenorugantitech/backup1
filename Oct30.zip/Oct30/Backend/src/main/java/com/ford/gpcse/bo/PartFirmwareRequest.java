package com.ford.gpcse.bo;

import com.ford.gpcse.dto.LookupProgramDescriptionDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class PartFirmwareRequest {
    private String assemblyPN;
    private String dRCdsId;
    private String hardwarePN;
    private String coreHardwarePN;
    private String mainMicroType;
    private List<LookupProgramDescriptionDto> programDescription;
    private String lineage;
}
