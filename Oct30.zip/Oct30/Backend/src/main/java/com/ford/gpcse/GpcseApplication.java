package com.ford.gpcse;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class GpcseApplication {

    public static void main(String[] args) {
        SpringApplication.run(GpcseApplication.class, args);
    }

    @Bean
    OpenAPI customOpenAPI(Environment env) {
        return new OpenAPI().components(new Components()).info(new Info()
                .title(env.getRequiredProperty("app.openApiTitle"))
                .description(env.getRequiredProperty("app.openApiDescription")));
    }

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}
