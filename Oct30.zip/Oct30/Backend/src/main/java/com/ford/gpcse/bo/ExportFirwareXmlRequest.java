package com.ford.gpcse.bo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExportFirwareXmlRequest {
    private List<String> partNumbers;
    private String concernNumber;
    private String wersNoticeNumber;
    private String fileName;
    private String exportVersion;
    private String createUser;
}
