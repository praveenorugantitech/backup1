package com.ford.gpcse.bo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class ReleaseRequestDetail {

    private String requestId;
    private String owner;
    private String status;
    private String moduleType;
    private String priority;
    private String priorityDriver;
    private String releaseConcernReason;
    private String firmwareProgram;
    private String calibrationRNumber;
    private String isCoordinationRequired;
    private String swStrategy;
    private String isBackwardCompatChange;
    private String buildEvent;
    private String calibrationReleaseDateCfx;
    private String projectControlEngineer;
    private String firmwareReleaseUsage;
    private String releaseTitle;
    private String isCalibrationCCMNumber;
    private String isAdditionalHwSwCoordRequired;
    private String hwSwCoordDetail;
    private String isAlertRequired;
    private String alertDetail;
    private String isRollingUsageRequired;
    private String rollingUsageChanges;
    private String buildStartDate;
    private String suppliertVbfDeliveryDate;
    private String appDREngineer;
    private String calibrationEngineer;
    private String calibrationReleaseSupport;
    private String hardwarePartNumber;
    private String ipfInstalledPartNumber;
    private String servicePartNumber;
}
