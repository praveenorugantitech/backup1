package com.ford.gpcse.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
public class ReleaseTypeFirmwareId {

    @Column(name = "PCMR15_REL_TYP_C", length = 5)
    private String relTypC;

    @Column(name = "PCMR03_FIRMWARE_K")
    private Long firmwareK;
}
