package com.ford.gpcse.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class WersTextPartCalibDto {
    private String partR;
    private String replacedPartR;
    private String catchwordC;
    private String partNumX;
    private String calibR;
    private String hardwarePartR;
    private String statC;
    private String oldCal;
    private String oldCw;
}
