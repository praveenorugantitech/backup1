package com.ford.gpcse.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import java.net.InetSocketAddress;
import java.net.Proxy;

/**
 * Configuration class to create a RestTemplate instance that routes
 * requests through a specified proxy. This is useful for applications
 * that need to access external services via a proxy server.
 */
@Configuration
public class RestTemplateProxyConfig {

    /**
     * Creates a RestTemplate bean configured to use a proxy.
     *
     * @return a RestTemplate instance with proxy settings.
     */
    @Bean
    public RestTemplate restTemplateWithProxy() {
        // Configure the proxy with host and port
        Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("internet.ford.com", 83));

        // Set up SimpleClientHttpRequestFactory with the proxy
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setProxy(proxy);

        // Create RestTemplate with the proxy-enabled factory
        return new RestTemplate(factory);
    }
}
