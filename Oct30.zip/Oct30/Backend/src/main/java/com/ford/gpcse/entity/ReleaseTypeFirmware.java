package com.ford.gpcse.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCMR23_REL_TYP_FIRMWARE")
public class ReleaseTypeFirmware {

    @EmbeddedId
    private ReleaseTypeFirmwareId id;

    @ManyToOne
    @JoinColumn(name = "PCMR15_REL_TYP_C", referencedColumnName = "PCMR15_REL_TYP_C", insertable = false, updatable = false)
    private ReleaseType releaseType;

    @ManyToOne
    @JoinColumn(name = "PCMR03_FIRMWARE_K", referencedColumnName = "PCMR03_FIRMWARE_K", insertable = false, updatable = false)
    private Firmware firmware;


    @Column(name = "PCMR23_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR23_CREATE_S", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR23_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR23_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;
}
