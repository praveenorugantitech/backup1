package com.ford.gpcse.repository;

import com.ford.gpcse.entity.FirmwareItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 * Repository interface for managing FirmwareItem entities.
 * This interface extends JpaRepository to provide CRUD operations.
 */
@Repository
public interface FirmwareItemRepository extends JpaRepository<FirmwareItem, String> {

    /**
     * Custom method to count FirmwareItem entities by firmware item description (PCMR22_FIRMWARE_ITM_X).
     *
     * @param firmwareItmX The firmware item description to count
     * @return The count of FirmwareItem entities matching the given description
     */
    @Query("SELECT COUNT(f) FROM FirmwareItem f WHERE f.firmwareItmX = :firmwareItmX")
    Long countByFirmwareItmX(@Param("firmwareItmX") String firmwareItmX);

    /**
     * Adds a new firmware item to the dropdown by inserting it into the database.
     * The insertion is based on a specified firmware type and module type.
     *
     * @param fwType      The firmware type to filter the firmware items
     * @param moduleType  The module type to filter related firmware items
     * @param itemToAdd   The firmware item to add to the dropdown
     * @param currentUser The user performing the addition
     */
    @Modifying
    @Transactional
    @Query(value = "INSERT INTO WPCMR22_FIRMWARE_ITM (PCMR03_FIRMWARE_K, PCMR22_FIRMWARE_ITM_X, PCMR22_SORT_ORD_R, PCMR22_CREATE_USER_C, PCMR22_CREATE_S, PCMR22_LAST_UPDT_USER_C, PCMR22_LAST_UPDT_S) " +
            "SELECT t1.PCMR03_FIRMWARE_K, :itemToAdd, 0, :currentUser, CURRENT_TIMESTAMP, :currentUser, CURRENT_TIMESTAMP " +
            "FROM WPCMR03_FIRMWARE t1 " +
            "JOIN WPCMR23_REL_TYP_FIRMWARE t2 ON t1.PCMR03_FIRMWARE_K = t2.PCMR03_FIRMWARE_K " +
            "WHERE t1.PCMR03_FIRMWARE_N LIKE :fwType " +
            "AND t2.PCMR15_REL_TYP_C IN (SELECT DISTINCT p.PCMR15_REL_TYP_C FROM WPCMR01_PART p WHERE p.PCMR14_MODULE_TYP_C = :moduleType) " +
            "LIMIT 1", nativeQuery = true)
    void addFirmwareItemToDropdown(
            @Param("fwType") String fwType,
            @Param("moduleType") String moduleType,
            @Param("itemToAdd") String itemToAdd,
            @Param("currentUser") String currentUser);
}
