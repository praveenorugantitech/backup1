package com.ford.gpcse.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCMR24_REL_USG")
public class RelUsg {

    @Id
    @Column(name = "PCMR24_REL_USG_C", nullable = false)
    private String relUsgC;

    @Column(name = "PCMR24_REL_USG_X")
    private String relUsgX;

    @Column(name = "PCMR24_ARCH_F")
    private String archF;

    @Column(name="PCMR24_SORT_ORD_R")
    private String sortOrdR;


    @Column(name = "PCMR24_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR24_CREATE_S", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR24_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR24_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;
}
