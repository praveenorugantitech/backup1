package com.ford.gpcse.bo;

import com.ford.gpcse.dto.LookupPartFirmwareDto;
import com.ford.gpcse.dto.LookupProgramDescriptionDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class PartFirmwareResponse {
    private String assemblyPN;
    private String dRCdsId;
    private String hardwarePN;
    private String coreHardwarePN;
    private String mainMicroType;
    private List<LookupProgramDescriptionDto> programDescriptions;
    private String lineage;
    private List<LookupPartFirmwareDto> partFirmwares;
}
