package com.ford.gpcse.controller;

import com.ford.gpcse.aop.LoggingAspect;
import com.ford.gpcse.aop.TrackExecutionTime;
import com.ford.gpcse.bo.SupplierEnrollmentRequest;
import com.ford.gpcse.service.EnrollmentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller for handling supplier enrollment operations.
 * This class provides an endpoint for suppliers to enroll and
 * includes logging and execution time tracking features.
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1_0/enrollment")
@Tag(description = "Supplier Enrollment", name = "Enrollment Operations")
public class EnrollmentController {

    private final EnrollmentService enrollmentService; // Service for handling enrollment logic

    /**
     * Endpoint for supplier enrollment.
     *
     * @param supplierEnrollmentRequest the request body containing supplier enrollment data
     * @return a ResponseEntity with a success message
     */
    @TrackExecutionTime  // Track the execution time of this method
    @LoggingAspect  // Enable logging for this method
    @PostMapping(value = "/supplier")
    @Operation(
            summary = "Supplier Enrollment",
            description = "Supplier Enrollment"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully Sent Supplier Enrollment Email")
    })
    public ResponseEntity<String> supplierEnrollment(@RequestBody SupplierEnrollmentRequest supplierEnrollmentRequest) {
        // Call the enrollment service to process the supplier enrollment request
        return ResponseEntity.ok(enrollmentService.supplierEnrollment(supplierEnrollmentRequest));
    }
}
