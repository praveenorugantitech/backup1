import { Component, OnInit } from "@angular/core";
import {
  ActivatedRouteSnapshot,
  NavigationEnd,
  Router,
  RouterOutlet,
} from "@angular/router";
import { HeaderComponent } from "./common/header/header.component";
import { FooterComponent } from "./common/footer/footer.component";
import { Title } from "@angular/platform-browser";
import { filter } from "rxjs/operators";

@Component({
  selector: "app-root",
  standalone: true,
  imports: [HeaderComponent, RouterOutlet, FooterComponent],
  templateUrl: "./app.component.html",
  styleUrl: "./app.component.scss",
})
export class AppComponent implements OnInit {
  constructor(private titleService: Title, private router: Router) {}

  ngOnInit() {
    // Set a default title
    this.titleService.setTitle("PCMSPECNG");

    // Subscribe to router events
    this.router.events
      .pipe(filter((event) => event instanceof NavigationEnd))
      .subscribe(() => {
        const currentRoute = this.router.routerState.snapshot.root;
        this.updateTitle(currentRoute);
      });
  }

  private updateTitle(route: ActivatedRouteSnapshot) {
    // Traverse to the deepest child route
    while (route.firstChild) {
      route = route.firstChild;
    }
    // Access the data using the snapshot
    const title = route.data["title"] || "PCMSPECNG";
    this.titleService.setTitle(title);
  }
}
