import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DrrRoutingModule } from './drr-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    DrrRoutingModule
  ]
})
export class DrrModule { }
