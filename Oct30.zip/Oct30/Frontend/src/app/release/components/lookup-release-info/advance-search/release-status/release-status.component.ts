import { Component, OnDestroy, OnInit } from "@angular/core";
import { HttpErrorResponse } from "@angular/common/http";
import { ErrorResponse } from "../../../../utils/models/error-response.model";
import { ReleaseUtils } from "../../../../utils/ReleaseUtils";
import { ReleaseService } from "../../../../utils/services/release.service";
import { Router } from "@angular/router";
import { Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";
@Component({
  selector: "app-release-status",
  templateUrl: "./release-status.component.html",
})
export class ReleaseStatusComponent implements OnInit, OnDestroy {
  releaseStatuses: any[] = [];
  concern: string = "";
  displayConcernDetails: boolean = false;
  firmwareRecord: any = {};
  private unsubscribe$ = new Subject<void>();

  constructor(
    private router: Router,
    private releaseService: ReleaseService   
  ) {}

  ngOnInit() {  
    this.fetchReleaseStatuses();
  }

  fetchReleaseStatuses() {
    this.releaseService.getReleaseStatusDetails().subscribe((data) => {
      this.releaseStatuses = data;
    });
  }

  onSubmit(concern: string) {
    this.concern = concern;
    if (this.concern) {
      this.releaseService
        .getReleaseStatusDetailsByWersConcern(this.concern)
        .pipe(takeUntil(this.unsubscribe$))
        .subscribe({
          next: (response: any) => {
            this.firmwareRecord = response;
            this.displayConcernDetails = true;
          },
          error: (error: HttpErrorResponse) => this.handleError(error),
        });
    }
  }

  cancelSubmit() {
    window.scrollTo({ top: 0, behavior: "smooth" });
    this.router.navigate(["/"]);
  }

  ngOnDestroy() {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage = "An unexpected error occurred.";

    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message; // Client-side error
    } else if (typeof error.error === "string") {
      try {
        const errorResponse: ErrorResponse = JSON.parse(error.error);
        errorMessage = errorResponse.message || errorMessage;
      } catch {
        console.error("Error parsing response");
      }
    } else if (error.error?.message) {
      errorMessage = error.error.message; // Server-side error
    }

    ReleaseUtils.showErrorSweetAlert("Error", errorMessage);
  }
}
