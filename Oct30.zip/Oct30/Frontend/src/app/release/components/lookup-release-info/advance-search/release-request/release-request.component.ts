import { Component, OnDestroy, OnInit } from "@angular/core";
import { ReleaseService } from "../../../../utils/services/release.service";
import { Router } from "@angular/router";
import {
  ReleaseRequestDetailModel,
  ReleaseRequestGetModel,
} from "../../../../utils/models/release-request.model";
import { HttpErrorResponse } from "@angular/common/http";
import { ErrorResponse } from "../../../../utils/models/error-response.model";
import { ReleaseUtils } from "../../../../utils/ReleaseUtils";
import { Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";

@Component({
  selector: "app-release-request",
  templateUrl: "./release-request.component.html",
  styleUrl: "./release-request.component.scss",
})
export class ReleaseRequestComponent implements OnInit, OnDestroy {
  errorMessage: string = "";
  searchParams = {
    id: "",
    module: "",
    rLevel: "",
    status: "",
    owner: "",
    modelYear: "",
    program: "",
    engine: "",
  };
  statuses: string[] = [
    "New",
    "Project Control",
    "D&R Engineer",
    "Cal Release Engineer",
    "Complete",
  ];
  releaseRequestDetails: any[] = [];
  displayReleaseRequestDetail: boolean = false;
  private unsubscribe$ = new Subject<void>();
  releaseRequestDetail: ReleaseRequestDetailModel =
    new ReleaseRequestDetailModel();
  isRequestIdReadonly: boolean = true;

  constructor(private router: Router, private releaseService: ReleaseService) {}

  ngOnInit() {
    this.fetchReleaseRequestDetails();
  }

  fetchReleaseRequestDetails() {
    this.releaseService.getReleaseRequestDetails().subscribe((data) => {
      this.releaseRequestDetails = data;
    });
  }

  onSubmit(id: string) {
    this.displayReleaseRequestDetail = true;
    
    this.releaseService.getRequestDetailById(id).subscribe((data) => {
      this.releaseRequestDetail = data;
      
    });
  }

  onSearch() {
    const { id, module, rLevel, status, owner, modelYear, program, engine } =
      this.searchParams;

    const dataToSend: ReleaseRequestGetModel = {
      id,
      module,
      rLevel,
      status,
      owner,
      modelYear,
      program,
      engine,
      createUser: "DSADASH1",
      lastUpdateUser: "DSADASH1",
    };

    this.releaseService
      .getReleaseRequestSearchDetails(dataToSend)
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe({
        next: (response: any) => {
          this.releaseRequestDetails = response;
        },
        error: (error: HttpErrorResponse) => this.handleError(error),
      });
  }

  clearSearch() {
    this.searchParams = {
      id: "",
      module: "",
      rLevel: "",
      status: "",
      owner: "",
      modelYear: "",
      program: "",
      engine: "",
    };
    this.fetchReleaseRequestDetails();
  }

  exportToExcel() {
    const { id, module, rLevel, status, owner, modelYear, program, engine } =
      this.searchParams;

    // Check if all parameters are empty (or null/undefined)
    const allEmpty =
      !module &&
      !rLevel &&
      !status &&
      !owner &&
      !modelYear &&
      !program &&
      !engine;

    // Set id to -1 if all other parameters are empty
    const finalId = allEmpty ? "-1" : id;

    const dataToSend: ReleaseRequestGetModel = {
      id: finalId,
      module,
      rLevel,
      status,
      owner,
      modelYear,
      program,
      engine,
      createUser: "DSADASH1",
      lastUpdateUser: "DSADASH1",
    };

    this.releaseService
      .exportReleaseRequestDetailsToExcel(dataToSend)
      .subscribe(
        (response) => {
          const blob = new Blob([response], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          });

          let filename = "ReleaseRequestSearchResult.xlsx"; // Default filename

          const url = window.URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = url;
          a.download = filename; // Use the fetched filename
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          window.URL.revokeObjectURL(url);
        },
        (error) => {
          console.error("Error exporting parts to excel:", error);
        }
      );
  }

  ngOnDestroy() {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage = "An unexpected error occurred.";

    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message; // Client-side error
    } else if (typeof error.error === "string") {
      try {
        const errorResponse: ErrorResponse = JSON.parse(error.error);
        errorMessage = errorResponse.message || errorMessage;
      } catch {
        console.error("Error parsing response");
      }
    } else if (error.error?.message) {
      errorMessage = error.error.message; // Server-side error
    }

    ReleaseUtils.showErrorSweetAlert("Error", errorMessage);
  }
}
