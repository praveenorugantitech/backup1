import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-module-base-info',
  templateUrl: './edit-module-base-info.component.html',
  styleUrl: './edit-module-base-info.component.scss'
})
export class EditModuleBaseInfoComponent {

}
