import { Component } from '@angular/core';

@Component({
  selector: 'app-calibration-engineer',
  templateUrl: './calibration-engineer.component.html',
  styleUrl: './calibration-engineer.component.scss'
})
export class CalibrationEngineerComponent {

}
