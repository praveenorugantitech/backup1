import { Component } from '@angular/core';

@Component({
  selector: 'app-add-program-to-released-part',
  templateUrl: './add-program-to-released-part.component.html',
  styleUrl: './add-program-to-released-part.component.scss'
})
export class AddProgramToReleasedPartComponent {

}
