import { Component } from "@angular/core";
import { ReleaseService } from "../../../utils/services/release.service";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ErrorResponse } from "../../../utils/models/error-response.model";
import Swal from "sweetalert2";
import { Router } from "@angular/router";
import { ReleaseUtils } from "../../../utils/ReleaseUtils";

@Component({
  selector: "app-user-enrollment",
  templateUrl: "./user-enrollment.component.html",
  styleUrls: ["./user-enrollment.component.scss"],
})
export class UserEnrollmentComponent {
  userForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private releaseService: ReleaseService,
    private router: Router
  ) {
    this.userForm = this.fb.group({
      userId: ["", Validators.required],
      firstName: ["", Validators.required],
      lastName: ["", Validators.required],
      email: ["", [Validators.required, Validators.email]],
      comments: [""],
    });
  }

  onSubmit() {
    if (this.userForm.valid) {
      this.releaseService.submitUserEnrollment(this.userForm.value).subscribe(
        (response) => {
          const successMessage = response;
          Swal.fire({
            icon: "success",
            title: "Success",
            text: successMessage,
            confirmButtonColor: "#00467f",
          }).then(() => {
            this.router.navigate(["/"]);
          });
        },
        (error) => {
          let errorResponse: ErrorResponse;
          try {
            errorResponse = JSON.parse(error.error);
          } catch (e) {
            errorResponse = {
              status: "error",
              message: "An unexpected error occurred.",
            };
          }

          const errorMessage =
            errorResponse.message || "An unexpected error occurred.";
          ReleaseUtils.showErrorSweetAlert("Error", `${errorMessage}`);
        }
      );
    } else {
      const errorMessages = this.getFormValidationErrors();
      ReleaseUtils.showErrorSweetAlert("Error", errorMessages);
    }
  }

  getFormValidationErrors(): string {
    const messages: string[] = []; // Explicitly define messages as a string array
    Object.keys(this.userForm.controls).forEach((key) => {
      const control = this.userForm.get(key);
      if (control?.invalid) {
        // Collect errors without touching or dirty checks
        messages.push(this.getErrorMessage(key));
      }
    });
    return messages.length ? messages.join(", ") : "Form is invalid";
  }

  getErrorMessage(field: string): string {
    const control = this.userForm.get(field);
    if (control?.hasError("required")) {
      return `${field} is required`;
    }
    if (control?.hasError("email")) {
      return "Invalid email format";
    }
    return "";
  }
}
