import { Component, OnDestroy, OnInit } from "@angular/core";
import { FirmwareDescriptionModel } from "../../../utils/models/firmware-description.model";
import { ReleaseService } from "../../../utils/services/release.service";
import { Router } from "@angular/router";
import { ModuleTypesOptionsModel } from "../../../utils/models/shared.model";
import { Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";
import { HttpErrorResponse } from "@angular/common/http";
import { ErrorResponse } from "../../../utils/models/error-response.model";
import { ReleaseUtils } from "../../../utils/ReleaseUtils";

@Component({
  selector: "app-firmware-description-and-owners",
  templateUrl: "./firmware-description-and-owners.component.html",
  styleUrl: "./firmware-description-and-owners.component.scss",
})
export class FirmwareDescriptionAndOwnersComponent
  implements OnInit, OnDestroy
{
  firmwareDescriptionData: FirmwareDescriptionModel =
    new FirmwareDescriptionModel();
  moduleTypeOptions: Array<ModuleTypesOptionsModel> = new Array();
  releaseTypeOptions: string[] = [];
  filteredOptionsModuleType: Array<ModuleTypesOptionsModel> = new Array();
  filteredOptionsReleaseType: string[] = [];
  firmwareRecords: any[] = [];
  private unsubscribe$ = new Subject<void>();

  constructor(private router: Router, private releaseService: ReleaseService) {}

  ngOnInit() {
    this.getModuleTypes();
  }

  getModuleTypes() {
    try {
      this.releaseService.getModuleTypes().subscribe((res) => {
        if (res.length > 0) {
          this.moduleTypeOptions = res;
          this.filterOptions("module_type");
        } else {
          console.error(
            "Something went wrong while fetching the module types."
          );
        }
      });
    } catch (err) {
      console.error(err);
    }
  }

  filterOptions(changeOpt: String) {
    if (changeOpt === "module_type") {
      if (this.firmwareDescriptionData.moduleTypeName) {
        this.filteredOptionsModuleType = this.moduleTypeOptions.filter(
          (option) =>
            option.moduleTypeName
              .toLowerCase()
              .includes(
                String(
                  this.firmwareDescriptionData.moduleTypeName.toLowerCase()
                )
              )
        );
      } else {
        this.filteredOptionsModuleType = this.moduleTypeOptions;
      }
    }

    if (changeOpt === "release_type") {
      if (this.firmwareDescriptionData.releaseType) {
        this.filteredOptionsReleaseType = this.releaseTypeOptions.filter(
          (option) =>
            option
              .toLowerCase()
              .includes(this.firmwareDescriptionData.releaseType.toLowerCase())
        );
      } else {
        this.filteredOptionsReleaseType = this.releaseTypeOptions;
      }
    }
  }

  handleModuleType(moduleTypeName: string) {
    // Reset release type  when a new module type is selected
    this.firmwareDescriptionData.releaseType = "";
    this.releaseTypeOptions = [];
    if (!moduleTypeName) return;
    const option = this.moduleTypeOptions.find(
      (opt) => opt.moduleTypeName === moduleTypeName
    );
    this.getReleaseTypes(option ? option.moduleTypeCode : "");
  }

  getReleaseTypes(moduleTypeCode: string) {
    if (moduleTypeCode) {
      try {
        this.releaseService.getReleaseTypesByModuleType(moduleTypeCode).subscribe(
          (res: string[]) => {
            this.releaseTypeOptions = res;
            this.filterOptions("release_type");
          },
          (error) => {
            console.error("Error fetching release types:", error);
            this.resetReleaseType(); // Reset on error
          }
        );
      } catch (err) {
        console.error(err);
        this.resetReleaseType(); // Reset in case of an exception
      }
    }
  }

  resetReleaseType() {
    this.firmwareDescriptionData.releaseType = ""; // Resetting the release type
    this.releaseTypeOptions = []; // Clear release type options as well
  }

  displayFirmwareDetails() {
    this.releaseService
      .getFirmwareDetailsByReleaseType(this.firmwareDescriptionData.releaseType)
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe({
        next: (response: any) => {
          this.firmwareRecords = Array.isArray(response) ? response : [];
        },
        error: (error: HttpErrorResponse) => this.handleError(error),
      });
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage = "An unexpected error occurred.";

    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message; // Client-side error
    } else if (typeof error.error === "string") {
      try {
        const errorResponse: ErrorResponse = JSON.parse(error.error);
        errorMessage = errorResponse.message || errorMessage;
      } catch {
        console.error("Error parsing response");
      }
    } else if (error.error?.message) {
      errorMessage = error.error.message; // Server-side error
    }

    ReleaseUtils.showErrorSweetAlert("Error", errorMessage);
  }

  onCancelClick() {
    this.firmwareDescriptionData = new FirmwareDescriptionModel();
    this.resetReleaseType();
    window.scrollTo({ top: 0, behavior: "smooth" });
    this.router.navigate(["/"]);
  }

  ngOnDestroy() {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }
}
