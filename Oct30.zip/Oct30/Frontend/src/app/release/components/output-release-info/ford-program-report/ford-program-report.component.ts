import { Component } from '@angular/core';

@Component({
  selector: 'app-ford-program-report',
  templateUrl: './ford-program-report.component.html',
  styleUrl: './ford-program-report.component.scss'
})
export class FordProgramReportComponent {

}
