export class exportToExcelPostModel {
  partNumbers: string[] = [];
  fileName: string = "";
  concernC: string = "";
  wersNtcR: string = "";
  exportVersion: string = "";
  createUser: string = "";
}
