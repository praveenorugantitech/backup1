import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class FileDownloadService {
  openFile(path: string) {
    const fileMapping: { [key: string]: string } = {
      'bulk-mail-guide': 'release/rel_proc/Bulk Mail Guide.pdf',
      'process-owners': 'https://www.lom.ford.com/launchomatic/launch/view.jsp?chronicleId=0900cad9811eb0ae&amp;docbase=edmsna1',
      'gpcse-module-release-process': 'release/rel_proc/GPCSE Module Release Process.pdf?v4',
      'jira-service-desk':'https://ford.atlassian.net/servicedesk/customer/portal/1147',
      'module-release-sharepoint': 'https://azureford.sharepoint.com/sites/GPCSEModuleRelease'
    };

    const fileUrl = fileMapping[path];
    if (fileUrl) {
      window.open(fileUrl, '_blank');
    } else {
      console.error('File not found for path:', path);
    }
  }
}
